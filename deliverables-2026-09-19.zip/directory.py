"""Departments & Contact tab — the campus directory with one-click email.

The official campus address is the page's visual anchor: a dark brand panel
at the top, with a monospace rendering that makes the address easy to read
aloud or type, and quick-action buttons beneath it.

Every department card carries its own pre-filled ``mailto:`` link, so a
student never has to compose an email from scratch — the subject and body
arrive ready, tagged with their own name and student ID.
"""

from __future__ import annotations

from typing import List

import streamlit as st

from portal import components as ui
from portal import state
from portal.data import DEPARTMENTS, ENQUIRY_TEMPLATES, Department, department_by_slug
from portal.logic import mailto
from portal.settings import CONTACT, PRIMARY_EMAIL, PRIMARY_EMAIL_LABEL

__all__ = ["render"]


def _tel_href(number: str) -> str:
    """Turn a display phone number into a dialable ``tel:`` link."""
    return "tel:" + "".join(ch for ch in number if ch.isdigit() or ch == "+")


# ===========================================================================
# Primary contact block
# ===========================================================================
def _primary_contact(student: dict) -> None:
    """The official campus address, given the visual weight it deserves."""
    quick = [
        {
            "label": "Email the campus front desk",
            "href": mailto.quick_mailto(
                subject="General enquiry from a new freshman",
                body=(
                    "Dear Garowe Campus team,\n\n"
                    "I am an incoming freshman and I would like to ask about "
                    "the following:\n\n\n\n"
                    "My details:\n"
                    f"Full name: {student.get('name') or ''}\n"
                    f"Student / application ID: {student.get('student_id') or ''}\n"
                    f"Programme: {student.get('programme') or ''}\n\n"
                    "Thank you,\n"
                    f"{student.get('name') or ''}\n"
                    f"{student.get('phone') or ''}"
                ),
                student=student,
            ),
            "variant": "gold",
        },
        {
            "label": f"Call {CONTACT['switchboard']}",
            "href": _tel_href(CONTACT["switchboard"]),
            "variant": "onDark",
        },
        {
            "label": "WhatsApp",
            "href": "https://wa.me/" + "".join(ch for ch in CONTACT["whatsapp"] if ch.isdigit()),
            "variant": "onDark",
        },
        {
            "label": "University website",
            "href": CONTACT["website"],
            "variant": "onDark",
        },
    ]

    body = (
        f'<p class="ghu-primary__label">{ui.esc(PRIMARY_EMAIL_LABEL)}</p>'
        f'<p class="ghu-primary__email">{ui.esc(PRIMARY_EMAIL)}</p>'
        f'<p class="ghu-small" style="color:rgba(255,253,248,.8);margin:0;">'
        f"This is the official Garowe Campus address and our primary contact "
        f"for all student enquiries. If you are unsure who to write to, write here — "
        f"we will route your message to the right office."
        f"</p>"
        f'<div class="ghu-primary__meta">'
        f"<div><b>Switchboard</b>{ui.esc(CONTACT['switchboard'])}</div>"
        f"<div><b>Opening hours</b>{ui.esc(CONTACT['hours'])}</div>"
        f"<div><b>Office</b>{ui.esc(CONTACT['office'])}</div>"
        f"<div><b>Campus</b>{ui.esc(CONTACT['city'])}</div>"
        f"</div>"
        f'<div class="ghu-btnrow">{ui.button_row(quick)}</div>'
    )
    st.markdown(f'<div class="ghu-primary">{body}</div>', unsafe_allow_html=True)


# ===========================================================================
# Enquiry templates
# ===========================================================================
def _template_library(student: dict) -> None:
    """Pre-written, pre-addressed emails for the most common questions."""
    st.markdown(
        f'<div class="ghu-section">{ui.section_head("Ready-to-send enquiries", "Pick the question closest to yours — the email opens pre-addressed and pre-filled with your details.")}</div>',
        unsafe_allow_html=True,
    )

    for template in ENQUIRY_TEMPLATES:
        dept = department_by_slug(template.dept)
        to_display = dept.email if dept else PRIMARY_EMAIL
        subject = mailto.render_template(template.subject, student)
        body = mailto.render_template(template.body, student)

        with st.expander(f"{template.label}"):
            st.markdown(
                f'<div class="ghu-dl">'
                f'<div class="ghu-dl__row"><div class="ghu-dl__k">To</div>'
                f'<div class="ghu-dl__v ghu-mono">{ui.esc(to_display)}</div></div>'
                f'<div class="ghu-dl__row"><div class="ghu-dl__k">Subject</div>'
                f'<div class="ghu-dl__v">{ui.esc(subject)}</div></div>'
                f"</div>",
                unsafe_allow_html=True,
            )
            st.markdown(
                f'<p class="ghu-kpi__label" style="margin:.7rem 0 .2rem 0;">'
                f"Message preview</p>"
                f'<div class="ghu-note" style="white-space:pre-wrap;">{ui.esc(body)}</div>',
                unsafe_allow_html=True,
            )
            st.markdown(
                ui.button_row(
                    [
                        {"label": "Open in my email app", "href": mailto.template_mailto(template, student)},
                        {"label": f"Email {to_display}", "href": f"mailto:{to_display}", "variant": "ghost"},
                    ]
                ),
                unsafe_allow_html=True,
            )


# ===========================================================================
# Department cards
# ===========================================================================
def _department_card(dept: Department, student: dict) -> None:
    """One department, with its contact person and one-click email."""
    subject = (
        f"Question for {dept.name} — "
        f"{student.get('name') or 'New freshman'}"
        f"{' (' + student['student_id'] + ')' if student.get('student_id') else ''}"
    )
    body = (
        f"Dear {dept.name},\n\n"
        f"I am a new freshman at Garowe Campus and I have a question:\n\n\n\n"
        f"My details:\n"
        f"Full name: {student.get('name') or ''}\n"
        f"Student / application ID: {student.get('student_id') or ''}\n"
        f"Programme: {student.get('programme') or ''}\n"
        f"Phone: {student.get('phone') or ''}\n\n"
        f"Thank you for your help.\n\n"
        f"Kind regards,\n{student.get('name') or ''}"
    )
    url = mailto.build_mailto(dept.email, subject, body)

    services = "".join(f"<li>{ui.esc(s)}</li>" for s in dept.services)

    inner = (
        f'<p class="ghu-dept__name">{ui.esc(dept.name)}</p>'
        f'<p class="ghu-dept__tag">{ui.esc(dept.tagline)}</p>'
        f'<p class="ghu-dept__person">{ui.esc(dept.contact_person)}</p>'
        f'<p class="ghu-dept__role">{ui.esc(dept.contact_role)}</p>'
        f'<p class="ghu-dept__mail">{ui.esc(dept.email)}</p>'
        f'<p class="ghu-small" style="margin:.5rem 0 0 0;">'
        f"📍 {ui.esc(dept.location)}<br/>🕘 {ui.esc(dept.hours)}<br/>"
        f"📞 {ui.esc(dept.phone)}</p>"
        f'<p class="ghu-small" style="margin:.6rem 0 .2rem 0;">{ui.esc(dept.description)}</p>'
        f'<ul class="ghu-dept__svc">{services}</ul>'
        f'<div class="ghu-btnrow">'
        f'{ui.button("Email this office", url, "primary")}'
        f'{ui.button(dept.phone, _tel_href(dept.phone), "ghost")}'
        f"</div>"
    )
    st.markdown(f'<div class="ghu-dept">{inner}</div>', unsafe_allow_html=True)


# ===========================================================================
# Tab entry point
# ===========================================================================
def render() -> None:
    """Draw the Departments & Contact tab."""
    student = state.get_student()
    personalised = bool(student.get("name"))

    st.markdown(
        f'<div class="ghu-section">{ui.section_head("Campus departments & contacts", "Nine campus offices, each with a direct email link. Every message opens pre-filled with your details.", "Directory")}</div>',
        unsafe_allow_html=True,
    )

    if not personalised:
        st.markdown(
            f'<div class="ghu-note" style="margin-bottom:1rem;">'
            f"💡 <b>Tip:</b> add your name and student ID in the sidebar, and every "
            f"email below will be pre-filled with them automatically."
            f"</div>",
            unsafe_allow_html=True,
        )

    # --- The primary campus address ----------------------------------------
    _primary_contact(student)

    # --- Directory ----------------------------------------------------------
    st.markdown(
        f'<div class="ghu-section">{ui.section_head("Department directory", "Direct contact for each office, in the order you are most likely to need them.")}</div>',
        unsafe_allow_html=True,
    )

    search_col, sort_col = st.columns([2, 1])
    with search_col:
        query = st.text_input(
            "Search the directory",
            placeholder="Search by office, service or contact name — e.g. 'library', 'fees', 'transcript'",
            key="dir_search",
        )
    with sort_col:
        sort_by = st.selectbox("Sort", ["Default order", "A – Z", "By contact person"], key="dir_sort")

    depts: List[Department] = list(DEPARTMENTS)
    needle = (query or "").strip().lower()
    if needle:
        def matches(d: Department) -> bool:
            haystack = " ".join(
                [d.name, d.tagline, d.description, d.contact_person, d.contact_role,
                 d.email, d.location, " ".join(d.services)]
            ).lower()
            return needle in haystack

        depts = [d for d in depts if matches(d)]
        st.markdown(
            f'<p class="ghu-small">{len(depts)} of {len(DEPARTMENTS)} offices match '
            f"&ldquo;{ui.esc(query)}&rdquo;.</p>",
            unsafe_allow_html=True,
        )
    elif sort_by == "A – Z":
        depts.sort(key=lambda d: d.name.lower())
    elif sort_by == "By contact person":
        depts.sort(key=lambda d: d.contact_person.split()[-1].lower())

    if not depts:
        st.markdown(
            ui.empty("No office matched that search. Try a broader term, or email the campus front desk above."),
            unsafe_allow_html=True,
        )
    else:
        for index in range(0, len(depts), 2):
            cols = st.columns(2, gap="medium")
            for col, dept in zip(cols, depts[index:index + 2]):
                with col:
                    _department_card(dept, student)

    # --- Ready-to-send templates -------------------------------------------
    _template_library(student)

    # --- Visiting / footer --------------------------------------------------
    st.markdown(
        f'<div class="ghu-section">{ui.section_head("Visiting the campus", "Where to find us, and when the offices are open.")}</div>',
        unsafe_allow_html=True,
    )
    st.markdown(
        ui.card(
            f'<div class="ghu-dl">'
            f'<div class="ghu-dl__row"><div class="ghu-dl__k">Address</div>'
            f'<div class="ghu-dl__v">{ui.esc(CONTACT["office"])}<br/>'
            f"{ui.esc(CONTACT['city'])}</div></div>"
            f'<div class="ghu-dl__row"><div class="ghu-dl__k">Getting here</div>'
            f'<div class="ghu-dl__v">{ui.esc(CONTACT["map_note"])}</div></div>'
            f'<div class="ghu-dl__row"><div class="ghu-dl__k">Office hours</div>'
            f'<div class="ghu-dl__v">{ui.esc(CONTACT["hours"])}</div></div>'
            f'<div class="ghu-dl__row"><div class="ghu-dl__k">Primary contact</div>'
            f'<div class="ghu-dl__v ghu-mono">{ui.esc(PRIMARY_EMAIL)}</div></div>'
            f'<div class="ghu-dl__row"><div class="ghu-dl__k">Alternate</div>'
            f'<div class="ghu-dl__v ghu-mono">{ui.esc(CONTACT["primary_email_alt"])}</div></div>'
            f"</div>",
        ),
        unsafe_allow_html=True,
    )

    st.markdown(
        f'<div class="ghu-foot">'
        f"All campus offices can be reached through the front desk at "
        f'<span class="ghu-mono">{ui.esc(PRIMARY_EMAIL)}</span>.'
        f"</div>",
        unsafe_allow_html=True,
    )
