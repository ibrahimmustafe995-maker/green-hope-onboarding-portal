"""Asset pipeline — resolves images for injection into the page HTML.

Two delivery modes, selected by ``brand.image_mode`` in ``config.yaml``:

``static`` (default)
    Streamlit serves the ``static/`` folder at ``app/static/<file>`` when
    ``enableStaticServing = true`` (set in ``.streamlit/config.toml``). The
    browser then fetches each image once and caches it, so an 800 KB hero
    photograph costs nothing on a rerun. This is the fast, idiomatic path.

``inline``
    Base64-encode the bytes into a ``data:`` URI. Fully self-contained — the
    page renders even if the static route is unavailable — but it
    re-transmits the whole image over the websocket on every rerun, so it is
    markedly slower.

Both modes are cached: ``data_uri`` avoids re-encoding, and the resolved
tag is cached because the same hero markup is rebuilt on every rerun.
"""

from __future__ import annotations

import base64
import mimetypes
import shutil
from functools import lru_cache
from pathlib import Path

from portal.settings import APP_DIR, ASSETS_DIR, CFG

__all__ = [
    "STATIC_DIR",
    "image_mode",
    "asset_path",
    "asset_exists",
    "img_src",
    "img_tag",
    "sync_static_dir",
]

# Guards against a typo'd filename silently inlining a huge file.
_MAX_INLINE_BYTES = 6 * 1024 * 1024  # 6 MB

# Where Streamlit expects static files to live for `enableStaticServing`.
STATIC_DIR: Path = APP_DIR / "static"


def image_mode() -> str:
    """Return the configured image mode: ``"static"`` or ``"inline"``."""
    mode = str(CFG.get("brand", {}).get("image_mode", "static")).strip().lower()
    return mode if mode in {"static", "inline"} else "static"


def asset_path(name: str) -> Path:
    """Absolute path of an asset inside ``assets/``."""
    return ASSETS_DIR / name


def _static_path(name: str) -> Path:
    """Absolute path of an asset inside ``static/``."""
    return STATIC_DIR / name


def asset_exists(name: str) -> bool:
    """True when the named asset is present and non-empty (either folder)."""
    for candidate in (asset_path(name), _static_path(name)):
        try:
            if candidate.is_file() and candidate.stat().st_size > 0:
                return True
        except OSError:  # pragma: no cover - unreadable filesystem entry
            continue
    return False


def sync_static_dir() -> list[str]:
    """Mirror every file from ``assets/`` into ``static/``.

    Called once at app start-up so that dropping a replacement image into
    ``assets/`` is enough — the developer never has to remember to copy it
    into ``static/`` as well. Returns the filenames now available.
    """
    STATIC_DIR.mkdir(parents=True, exist_ok=True)
    copied: list[str] = []
    if not ASSETS_DIR.is_dir():
        return copied

    for source in sorted(ASSETS_DIR.iterdir()):
        try:
            if not source.is_file() or source.stat().st_size == 0:
                continue
            target = _static_path(source.name)
            if not target.exists() or target.stat().st_size != source.stat().st_size:
                shutil.copy2(source, target)
            copied.append(source.name)
        except OSError:  # pragma: no cover - unwritable static dir
            continue
    return copied


@lru_cache(maxsize=32)
def data_uri(name: str) -> str:
    """Return a ``data:image/...;base64,...`` URI for an asset.

    Returns an empty string if the asset is missing or oversized, so callers
    fall back to a CSS-only treatment instead of rendering a broken tag.
    """
    path = asset_path(name)
    if not path.is_file():
        path = _static_path(name)
    if not path.is_file() or path.stat().st_size > _MAX_INLINE_BYTES:
        return ""

    mime, _ = mimetypes.guess_type(path.name)
    try:
        encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    except OSError:
        return ""
    return f"data:{mime or 'image/png'};base64,{encoded}"


@lru_cache(maxsize=64)
def img_src(name: str) -> str:
    """Resolve the ``src`` value for an asset, or ``""`` when unavailable.

    ``static`` mode prefers the served route ``app/static/<name>`` and falls
    back to a data-URI if that file is not on disk; ``inline`` mode always
    uses the data-URI.
    """
    if not asset_exists(name):
        return ""

    if image_mode() == "inline":
        return data_uri(name)

    if _static_path(name).is_file():
        return f"app/static/{name}"
    return data_uri(name)


@lru_cache(maxsize=64)
def _img_tag_cached(name: str, alt: str, css_class: str, style: str) -> str:
    """Cached builder for the ``<img>`` markup."""
    src = img_src(name)
    if not src:
        return ""

    classes = f' class="{css_class}"' if css_class else ""
    styles = f' style="{style}"' if style else ""
    safe_alt = (alt or name).replace('"', "&quot;")
    return f'<img src="{src}" alt="{safe_alt}"{classes}{styles} loading="lazy" />'


def img_tag(name: str, alt: str = "", css_class: str = "", style: str = "") -> str:
    """Build an ``<img>`` tag for an asset, or ``""`` when unavailable.

    ``alt`` is always emitted so the markup stays accessible.
    """
    return _img_tag_cached(name, alt, css_class, style)
