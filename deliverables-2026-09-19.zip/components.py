"""Reusable HTML component builders shared by the views.

Every function returns a string of HTML that the caller injects with
``st.markdown(..., unsafe_allow_html=True)``. Keeping the markup here means
the view modules read as *composition* rather than string plumbing, and the
visual language stays identical across all four tabs.

Two visual primitives are built by hand rather than pulled from a charting
library:

* the **SVG progress ring** — crisp at any zoom, and animatable without JS;
* the **CSS bar rows** — no canvas, so no layout measurement.

Both are immune to the zero-width rendering that charting libraries hit
inside *inactive* Streamlit tabs, where a canvas is laid out while hidden.
A Plotly chart is still used for the deadline countdown, where interactivity
(hover values) genuinely adds something.
"""

from __future__ import annotations

import math
from html import escape
from typing import Iterable, Sequence

from portal.settings import THEME
from portal.styles import FONT_BODY, FONT_DISPLAY

__all__ = [
    "esc",
    "chip",
    "chip_list",
    "kpi",
    "kpi_row",
    "bar_row",
    "bar_rows",
    "section_head",
    "card",
    "button",
    "button_row",
    "donut",
    "empty",
    "spacer",
]

# Variants accepted by chip()/kpi()/button() — anything else renders plain.
_CHIP_VARIANTS = {"gold", "grey", "success", "warning", "danger", "plain"}
_KPI_VARIANTS = {"gold", "warning"}
_BTN_VARIANTS = {"primary", "gold", "ghost", "onDark", "danger"}


# ===========================================================================
# Escaping
# ===========================================================================
def esc(value: object) -> str:
    """HTML-escape any value so user input can never break the markup."""
    return escape("" if value is None else str(value), quote=True)


# ===========================================================================
# Chips & KPIs
# ===========================================================================
def chip(label: str, variant: str = "") -> str:
    """A small pill. ``variant`` maps to a modifier class."""
    mod = f" ghu-chip--{variant}" if variant in _CHIP_VARIANTS else ""
    return f'<span class="ghu-chip{mod}">{esc(label)}</span>'


def chip_list(labels: Iterable[str], variant: str = "") -> str:
    """Several chips in a row."""
    return "".join(chip(str(x), variant) for x in labels if str(x).strip())


def kpi(label: str, value: str, note: str = "", variant: str = "") -> str:
    """One KPI tile: small caps label, large display value, optional note."""
    mod = f" ghu-kpi--{variant}" if variant in _KPI_VARIANTS else ""
    val_mod = f" ghu-kpi__value--{variant}" if variant in _KPI_VARIANTS else ""
    note_html = f'<p class="ghu-kpi__note">{esc(note)}</p>' if note else ""
    return (
        f'<div class="ghu-kpi{mod}">'
        f'<p class="ghu-kpi__label">{esc(label)}</p>'
        f'<p class="ghu-kpi__value{val_mod}">{esc(value)}</p>'
        f"{note_html}"
        f"</div>"
    )


def kpi_row(items: Sequence[dict]) -> str:
    """A responsive row of KPI tiles.

    Each item is a dict with ``label``, ``value`` and optional ``note`` /
    ``variant`` keys.
    """
    tiles = "".join(
        kpi(
            str(item.get("label", "")),
            str(item.get("value", "")),
            str(item.get("note", "")),
            str(item.get("variant", "")),
        )
        for item in items
    )
    return f'<div class="ghu-kpis">{tiles}</div>'


# ===========================================================================
# Bars
# ===========================================================================
def bar_row(
    label: str,
    percent: float,
    value_text: str = "",
    variant: str = "",
    thin: bool = False,
) -> str:
    """A labelled horizontal progress bar."""
    pct = max(0.0, min(100.0, float(percent or 0)))
    bar_mod = " ghu-bar--thin" if thin else ""
    fill_mod = " ghu-bar--gold" if variant == "gold" else ""
    return (
        f'<div class="ghu-barrow">'
        f'<div class="ghu-barrow__label">{esc(label)}</div>'
        f'<div class="ghu-barrow__track">'
        f'<div class="ghu-bar{bar_mod}{fill_mod}">'
        f'<div class="ghu-bar__fill" style="width:{pct:.1f}%"></div>'
        f"</div></div>"
        f'<div class="ghu-barrow__val">{esc(value_text)}</div>'
        f"</div>"
    )


def bar_rows(rows: Sequence[dict]) -> str:
    """Several :func:`bar_row` calls.

    Each row dict: ``label``, ``percent`` and optional ``value_text`` /
    ``variant`` / ``thin``.
    """
    return "".join(
        bar_row(
            str(row.get("label", "")),
            float(row.get("percent", 0) or 0),
            str(row.get("value_text", "")),
            str(row.get("variant", "")),
            bool(row.get("thin", False)),
        )
        for row in rows
    )


# ===========================================================================
# Structure
# ===========================================================================
def section_head(title: str, sub: str = "", eyebrow: str = "") -> str:
    """A section heading with the brand rule underneath."""
    eyebrow_html = f'<p class="ghu-eyebrow">{esc(eyebrow)}</p>' if eyebrow else ""
    sub_html = f'<p class="ghu-section__sub">{esc(sub)}</p>' if sub else ""
    return (
        f'<div class="ghu-section__head">{eyebrow_html}'
        f'<p class="ghu-h2">{esc(title)}</p>{sub_html}</div>'
    )


def card(inner_html: str, variant: str = "") -> str:
    """A white/sand surface that wraps arbitrary inner markup."""
    mod = f" ghu-card--{variant}" if variant else ""
    return f'<div class="ghu-card{mod}">{inner_html}</div>'


def button(label: str, href: str, variant: str = "primary", title: str = "") -> str:
    """An ``<a>`` styled as a button.

    A real anchor matters here: clicking a ``mailto:`` link must be handled
    by the browser's mail client, with no Streamlit round-trip.
    """
    mod = f" ghu-btn--{variant}" if variant in _BTN_VARIANTS else ""
    title_attr = f' title="{esc(title)}"' if title else ""
    return (
        f'<a class="ghu-btn{mod}" href="{esc(href)}"'
        f'{title_attr} target="_blank" rel="noopener noreferrer">{esc(label)}</a>'
    )


def button_row(buttons: Sequence[dict]) -> str:
    """Several buttons side by side.

    Each dict: ``label``, ``href`` and optional ``variant`` / ``title``.
    """
    inner = "".join(
        button(
            str(b.get("label", "")),
            str(b.get("href", "#")),
            str(b.get("variant", "primary")),
            str(b.get("title", "")),
        )
        for b in buttons
    )
    return f'<div class="ghu-btnrow">{inner}</div>'


# ===========================================================================
# SVG progress ring
# ===========================================================================
def donut(
    percent: float,
    caption: str = "",
    size: int = 210,
    thick: int = 19,
    fill: str | None = None,
) -> str:
    """A hand-built SVG progress ring.

    ``stroke-dasharray`` draws the arc; rotating -90° starts it at 12
    o'clock. Being inline SVG (not canvas) it stays sharp when zoomed and
    renders correctly even while its tab is hidden.
    """
    pct = max(0.0, min(100.0, float(percent or 0)))
    radius = (size - thick) / 2.0
    circumference = 2.0 * math.pi * radius
    dash = circumference * pct / 100.0
    mid = size / 2.0
    ring_colour = fill or THEME["primary"]
    cap = esc((caption or "").upper())

    return (
        f'<div style="display:flex;justify-content:center;">'
        f'<svg width="{size}" height="{size}" viewBox="0 0 {size} {size}" '
        f'role="img" aria-label="{pct:.0f} percent complete">'
        f'<circle cx="{mid}" cy="{mid}" r="{radius}" fill="none" '
        f'stroke="{THEME["sand"]}" stroke-width="{thick}" />'
        f'<circle cx="{mid}" cy="{mid}" r="{radius}" fill="none" '
        f'stroke="{ring_colour}" stroke-width="{thick}" stroke-linecap="round" '
        f'stroke-dasharray="{dash:.2f} {circumference:.2f}" '
        f'transform="rotate(-90 {mid} {mid})" />'
        f'<text x="{mid}" y="{mid + size * 0.02:.0f}" text-anchor="middle" '
        f'dominant-baseline="middle" font-family="{FONT_DISPLAY}" '
        f'font-size="{size * 0.255:.0f}" font-weight="700" fill="{THEME["ink"]}">'
        f"{pct:.0f}%</text>"
        f'<text x="{mid}" y="{mid + size * 0.155:.0f}" text-anchor="middle" '
        f'font-family="{FONT_BODY}" font-size="{size * 0.068:.0f}" '
        f'font-weight="700" letter-spacing="1.4" fill="{THEME["muted"]}">'
        f"{cap}</text>"
        f"</svg></div>"
    )


# ===========================================================================
# Misc
# ===========================================================================
def empty(message: str) -> str:
    """A friendly placeholder for an empty state."""
    return f'<div class="ghu-empty">{esc(message)}</div>'


def spacer(small: bool = False) -> str:
    """Vertical breathing room inside a markdown block."""
    return f'<div class="ghu-spacer{" ghu-spacer--sm" if small else ""}"></div>'
