"""Seed data for the portal.

Everything a freshman sees that is *content* rather than *logic* lives here:
the onboarding checklist, the campus department directory, the orientation
week schedule and the pre-written enquiry templates.

The structures are plain dataclasses so they are type-checked, immutable and
easy to swap for a database query later (``fetch_all_items()`` would simply
return rows mapped into the same dataclasses — no view code would change).

Checklist weighting
-------------------
Each item carries an integer ``weight`` and the ten weights sum to exactly
100, so the progress percentage is a plain weighted sum rather than an
arbitrary "10% per tick". Heavier items are the ones that genuinely block a
student from starting classes (fees, course registration, registration).

TODO (production): replace these literals with a query against the
``orientation_checklist_items`` and ``campus_departments`` tables.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Sequence, Tuple

from portal.settings import CONTACT, ORIENTATION

__all__ = [
    "ChecklistItem",
    "Department",
    "ScheduleEvent",
    "EnquiryTemplate",
    "CHECKLIST_ITEMS",
    "DEPARTMENTS",
    "ORIENTATION_SCHEDULE",
    "ENQUIRY_TEMPLATES",
    "PHASES",
    "CATEGORIES",
    "total_weight",
    "item_by_id",
    "department_by_slug",
]


# ===========================================================================
# Orientation phases — the three stages the checklist is grouped into.
# ===========================================================================
PHASES: Tuple[str, ...] = (
    "Phase 1 · Before You Arrive",
    "Phase 2 · Week One on Campus",
    "Phase 3 · Academic Setup",
)

PHASE_BLURBS: Dict[str, str] = {
    "Phase 1 · Before You Arrive": (
        "Complete these items before you travel to Garowe. They unlock everything else."
    ),
    "Phase 2 · Week One on Campus": (
        "Do these during orientation week, once you are physically on campus."
    ),
    "Phase 3 · Academic Setup": (
        "Finish these within the first fortnight so you are fully enrolled for teaching."
    ),
}

# Cross-cutting categories used for the "what kind of work is left" breakdown.
CATEGORIES: Tuple[str, ...] = (
    "Registration",
    "Finance",
    "IT & Access",
    "Campus Life",
    "Health",
    "Academic",
    "Compliance",
)


# ===========================================================================
# Checklist item
# ===========================================================================
@dataclass(frozen=True)
class ChecklistItem:
    """One onboarding step a freshman must complete.

    Attributes
    ----------
    id:        stable slug, also used as the persistence key.
    title:     short imperative label shown next to the checkbox.
    phase:     which of the three phases this belongs to.
    category:  cross-cutting category for the breakdown charts.
    weight:    contribution to the completion percentage (all sum to 100).
    dept:      slug of the owning department (see :data:`DEPARTMENTS`).
    deadline:  ISO date, or ``None`` when the step is not time-boxed.
    deadline_label: human-readable version of the deadline.
    summary:   one-sentence "why this matters".
    steps:     ordered, concrete instructions.
    documents: what to bring / have ready.
    fee:       any cost, or "No charge".
    location:  where to go, or the portal/online route.
    tip:       the kind of advice a helpful senior would give.
    """

    id: str
    title: str
    phase: str
    category: str
    weight: int
    dept: str
    deadline: str | None
    deadline_label: str
    summary: str
    steps: Tuple[str, ...]
    documents: Tuple[str, ...] = ()
    fee: str = "No charge"
    location: str = ""
    tip: str = ""


_ITEMS: Sequence[dict] = (
    # ----------------------------------------------------------------- Phase 1
    dict(
        id="reg_docs",
        title="Complete registration & submit your documents",
        phase=PHASES[0],
        category="Registration",
        weight=12,
        dept="admissions",
        deadline=ORIENTATION["registration_deadline"],
        deadline_label="30 Sep 2026",
        summary=(
            "Your place is only confirmed once Admissions has verified your "
            "original certificates and issued your enrolment number."
        ),
        steps=(
            "Log in to the Student Portal with the temporary credentials emailed to you.",
            "Open Enrolment → New Student and complete every field, including your "
            "Somali national ID or passport number.",
            "Scan and upload your secondary school certificate, birth certificate "
            "and two passport photographs (white background, 35 × 45 mm).",
            "Submit the form and note your application reference number.",
            "Bring the ORIGINAL documents to the Admissions counter in your first "
            "week for physical verification — uploads alone are not sufficient.",
            "Collect your signed enrolment confirmation letter before paying fees.",
        ),
        documents=(
            "Original secondary school certificate (or attested copy)",
            "Birth certificate or national ID / passport",
            "Two recent passport photographs",
            "Completed medical form (if available)",
            "Receipt of application fee, if already paid",
        ),
        location="Student Portal → Enrolment → New Student, then Administration Block A, Room 104",
        tip=(
            "Photograph your documents with good lighting on a plain background. "
            "Blurry or angled scans are the single most common cause of a rejected "
            "application and add roughly a week to the process."
        ),
    ),
    dict(
        id="email_portal",
        title="Activate your university email & student portal",
        phase=PHASES[0],
        category="IT & Access",
        weight=8,
        dept="it",
        deadline=None,
        deadline_label="As soon as you receive your credentials",
        summary=(
            "Your @student.greenhopeuniversity.edu.so address is the official "
            "channel for timetables, exam notices, results and fee reminders."
        ),
        steps=(
            "Find the activation email sent to the personal address on your application.",
            "Open the activation link within 72 hours — the token expires after that.",
            "Set a strong password (12+ characters). Do not reuse a password from "
            "another service.",
            "Enrol in two-factor authentication in the portal under Security → MFA.",
            "Log in to the Student Portal and confirm your programme, faculty and "
            "student ID number are correct.",
            "Add the account to your phone's mail app so you never miss a notice.",
        ),
        documents=("Your student ID number", "Access to the personal email you applied with"),
        location="Student Portal login page, or IT Support (Library Building, Room 006)",
        tip=(
            "If your activation link has expired, do not create a second account — "
            "email IT Support and they will reissue the token. Duplicate accounts "
            "delay your course registration."
        ),
    ),
    dict(
        id="tuition",
        title="Pay tuition & fees (or set up an instalment plan)",
        phase=PHASES[0],
        category="Finance",
        weight=15,
        dept="finance",
        deadline=ORIENTATION["fees_deadline"],
        deadline_label="5 Oct 2026",
        summary=(
            "Fee payment is what releases your course registration. The Bursar "
            "offers a two-instalment plan for students who need it."
        ),
        steps=(
            "Collect your personalised fee statement from the Student Portal "
            "(Finance → My Statement) or the Bursar's counter.",
            "Choose a payment channel: campus cashier, bank transfer to the "
            "university account, or approved mobile money (EVC Plus / eDahab / Zaad).",
            "If paying by bank or mobile money, keep the transaction reference and "
            "quote your student ID in the payment narration.",
            "Bring or email the payment proof to the Bursar's office for posting.",
            "Ask for an official stamped receipt — an SMS confirmation alone is not "
            "accepted as proof at registration.",
            "If you cannot pay in full, ask the Bursar for the instalment agreement "
            "before the deadline rather than after it.",
        ),
        documents=(
            "Fee statement / invoice",
            "Student ID number",
            "Payment proof (bank slip, mobile-money confirmation)",
            "Instalment agreement form, if applicable",
        ),
        fee="Programme-dependent — see your fee statement",
        location="Administration Block A, Room 012 (Cashier's counter)",
        tip=(
            "Pay early in the day. Counter queues are longest in the final three "
            "days before the deadline, and same-day postings can be missed if you "
            "arrive after 3:00 PM."
        ),
    ),
    # ----------------------------------------------------------------- Phase 2
    dict(
        id="id_card",
        title="Collect your student ID card",
        phase=PHASES[1],
        category="Registration",
        weight=8,
        dept="admissions",
        deadline=None,
        deadline_label="Within your first week on campus",
        summary=(
            "The ID card is required to sit examinations, borrow library books, "
            "enter the hostels and use campus printing."
        ),
        steps=(
            "Confirm your registration is verified in the Student Portal.",
            "Go to the Admissions counter during office hours and present your "
            "enrolment confirmation letter.",
            "Have your photograph taken at the counter (or bring one if instructed).",
            "Check your name, programme and student ID are printed correctly.",
            "Sign the ID register to confirm collection.",
            "Report a lost card to Admissions immediately — replacements carry a fee.",
        ),
        documents=("Enrolment confirmation letter", "National ID or passport"),
        fee="First card free · replacement fee applies",
        location="Administration Block A, Room 104 (Admissions counter)",
        tip=(
            "Check the spelling of your name before you leave the counter. A "
            "misprinted card can cause problems at exam halls, and reprints take "
            "several days."
        ),
    ),
    dict(
        id="hostel",
        title="Confirm your hostel / dorm allocation",
        phase=PHASES[1],
        category="Campus Life",
        weight=10,
        dept="hostel",
        deadline=None,
        deadline_label="During orientation week",
        summary=(
            "On-campus accommodation is allocated first-come, first-served. "
            "Commuting students should still register their address."
        ),
        steps=(
            "Decide between on-campus hostel and off-campus housing.",
            "If applying for the hostel, submit the accommodation form at the "
            "Hostel & Welfare Office.",
            "Attend the allocation session; rooms are assigned by programme and gender.",
            "Collect your room key, mattress slip and bedding pack.",
            "Inspect the room with the warden and report any pre-existing damage in writing.",
            "If living off campus, register your Garowe address so campus transport "
            "and emergency contact records are accurate.",
        ),
        documents=(
            "Student ID (temporary slip accepted)",
            "Accommodation application form",
            "Hostel fee receipt",
        ),
        fee="Per-semester hostel fee — see fee statement",
        location="Hostel & Welfare Office, near Block C",
        tip=(
            "Photograph the room on day one, including any existing marks or damage. "
            "It protects you from being charged for it at check-out."
        ),
    ),
    dict(
        id="health",
        title="Complete your health check & insurance enrolment",
        phase=PHASES[1],
        category="Health",
        weight=7,
        dept="health",
        deadline=None,
        deadline_label="Within your first two weeks",
        summary=(
            "The campus health check protects you and your classmates, and "
            "insurance enrolment is required before you can use the clinic."
        ),
        steps=(
            "Book a slot at the Campus Health Center (walk-ins accepted off-peak).",
            "Bring your immunisation records and, if you have one, your medical history.",
            "Complete the basic screening: vitals, and any required vaccination.",
            "Enrol in the student health insurance scheme and note your policy number.",
            "Save the clinic's emergency number to your phone.",
            "If you take regular medication, ask about the campus pharmacy stock.",
        ),
        documents=(
            "Immunisation / vaccination records",
            "Student ID",
            "Any existing medical records or prescriptions",
        ),
        fee="Health insurance premium — see fee statement",
        location="Campus Health Center, opposite the Library",
        tip=(
            "Go early in the morning when the clinic is quiet. Screening slots "
            "fill fastest in the days right before teaching begins."
        ),
    ),
    dict(
        id="orientation",
        title="Attend all orientation week sessions",
        phase=PHASES[1],
        category="Campus Life",
        weight=12,
        dept="student_affairs",
        deadline=ORIENTATION["week_end"],
        deadline_label="21 – 25 Sep 2026",
        summary=(
            "Orientation is where you meet your advisor, get your timetable and "
            "learn the systems you will use daily. Attendance is recorded."
        ),
        steps=(
            "Check the orientation timetable on the Welcome tab of this portal.",
            "Attend the welcome assembly and campus safety briefing on day one.",
            "Attend the academic integrity and assessment-rules session.",
            "Join the library tour and connect to campus Wi-Fi with your student login.",
            "Meet your faculty advisor in the departmental meet-and-greet.",
            "Sign the attendance register at every session — it is part of your file.",
        ),
        documents=("Student ID (temporary slip accepted)", "Notebook for your timetable"),
        location="Main Auditorium, then various venues per the schedule",
        tip=(
            "Ask your faculty advisor for a suggested first-semester course load "
            "during orientation. Get it right the first time and you avoid a "
            "drop-and-add later."
        ),
    ),
    # ----------------------------------------------------------------- Phase 3
    dict(
        id="course_reg",
        title="Register for your semester courses",
        phase=PHASES[2],
        category="Academic",
        weight=14,
        dept="advising",
        deadline=ORIENTATION["course_registration_deadline"],
        deadline_label="8 Oct 2026",
        summary=(
            "Course registration determines your timetable, your exam entries and "
            "your eligibility for results. It cannot be skipped."
        ),
        steps=(
            "Review your programme's first-semester study plan in the Student Portal.",
            "Book a short session with your academic advisor to confirm the load.",
            "Select your core (compulsory) courses first — these are auto-listed for you.",
            "Add electives up to the approved credit limit for your programme.",
            "Check for timetable clashes before submitting; the portal flags them in red.",
            "Submit registration and confirm your status reads 'Registered', not "
            "'Pending'.",
            "Download your timetable and note the exam-entry confirmation.",
        ),
        documents=("Fee payment receipt", "Advising session notes", "Programme study plan"),
        location="Student Portal → Registration → Course Selection, with Academic Advising",
        tip=(
            "'Pending' is not 'Registered'. If your status has not changed within "
            "24 hours of submitting, contact Academic Advising the same week — "
            "late changes attract the drop-and-add fee."
        ),
    ),
    dict(
        id="library",
        title="Activate your library card & induction",
        phase=PHASES[2],
        category="Academic",
        weight=6,
        dept="library",
        deadline=None,
        deadline_label="First two weeks of teaching",
        summary=(
            "The library holds your set texts, past papers and the e-resources "
            "you will need for assignments."
        ),
        steps=(
            "Take your student ID to the library front desk to activate borrowing.",
            "Attend the short induction on the catalogue and e-resource access.",
            "Borrow your first set text and note the due date.",
            "Set up off-campus access to the journal databases with your student login.",
            "Book a group study room if you need one for project work.",
            "Note the fines policy and the opening hours during exam periods.",
        ),
        documents=("Student ID card",),
        location="University Library, ground floor desk",
        tip=(
            "Set a phone reminder two days before each due date. Overdue fines "
            "block your exam clearance at the end of semester."
        ),
    ),
    dict(
        id="handbook",
        title="Read & acknowledge the student handbook",
        phase=PHASES[2],
        category="Compliance",
        weight=8,
        dept="student_affairs",
        deadline=None,
        deadline_label="Within your first month",
        summary=(
            "The handbook sets out assessment rules, attendance requirements, "
            "the misconduct process and your right to appeal. Acknowledging it "
            "is mandatory."
        ),
        steps=(
            "Open the Student Handbook 2026/27 from the portal or collect a printed copy.",
            "Read the sections on attendance, assessment and academic integrity.",
            "Note the grading scale, the pass mark and the progression rules.",
            "Read the complaints and appeals procedure so you know your rights early.",
            "Sign the digital acknowledgement form in the Student Portal.",
            "Keep a copy of the acknowledgement for your records.",
        ),
        documents=("Student ID number",),
        location="Student Portal → My Enrolment → Handbook Acknowledgement",
        tip=(
            "The academic integrity section matters most in your first term. "
            "Understand what counts as plagiarism before your first assignment, "
            "not after a misconduct hearing."
        ),
    ),
)


CHECKLIST_ITEMS: Tuple[ChecklistItem, ...] = tuple(
    ChecklistItem(
        steps=tuple(raw["steps"]),
        documents=tuple(raw.get("documents", ())),
        **{k: v for k, v in raw.items() if k not in {"steps", "documents"}},
    )
    for raw in _ITEMS
)


# ===========================================================================
# Campus department directory
# ===========================================================================
@dataclass(frozen=True)
class Department:
    """A campus office a freshman may need to contact."""

    slug: str
    name: str
    tagline: str
    description: str
    contact_person: str
    contact_role: str
    email: str
    phone: str
    location: str
    hours: str
    services: Tuple[str, ...] = ()
    handles: Tuple[str, ...] = ()  # checklist item ids this office owns


DEPARTMENTS: Tuple[Department, ...] = (
    Department(
        slug="admissions",
        name="Admissions & Registrar",
        tagline="Enrolment, records and student ID",
        description=(
            "The front door of the university. Admissions verifies your "
            "certificates, confirms your enrolment, issues your student ID and "
            "maintains your official academic record throughout your studies."
        ),
        contact_person="Ms. Hodan Farah",
        contact_role="Head of Admissions & Registrar",
        email="admissions@greenhopeuniversity.edu.so",
        phone="+252 90 7 000 110",
        location="Administration Block A, Room 104",
        hours="Sunday – Thursday · 8:00 AM – 4:00 PM",
        services=(
            "Application & document verification",
            "Enrolment confirmation letters",
            "Student ID card issuance & replacement",
            "Transcripts and academic records",
            "Programme transfer and deferment requests",
        ),
        handles=("reg_docs", "id_card"),
    ),
    Department(
        slug="finance",
        name="Finance / Bursar's Office",
        tagline="Fees, instalments and receipts",
        description=(
            "Handles everything financial: tuition and hostel payments, "
            "instalment agreements, official receipts, refunds, and the "
            "scholarships and bursaries the university administers."
        ),
        contact_person="Mr. Abdirahman Jama",
        contact_role="Campus Bursar",
        email="bursar@greenhopeuniversity.edu.so",
        phone="+252 90 7 000 120",
        location="Administration Block A, Room 012 (Cashier's counter)",
        hours="Sunday – Thursday · 8:00 AM – 3:30 PM",
        services=(
            "Tuition and hostel fee payment",
            "Instalment plan agreements",
            "Official stamped receipts",
            "Refund processing",
            "Scholarship, bursary and sponsorship queries",
        ),
        handles=("tuition",),
    ),
    Department(
        slug="student_affairs",
        name="Student Affairs",
        tagline="Orientation, welfare and student life",
        description=(
            "Your advocate on campus. Student Affairs runs orientation week, "
            "supports student clubs and the student council, and is the first "
            "port of call for welfare concerns, complaints and disputes."
        ),
        contact_person="Ms. Fartun Ali",
        contact_role="Dean of Student Affairs",
        email="studentaffairs@greenhopeuniversity.edu.so",
        phone="+252 90 7 000 130",
        location="Student Centre, Room 201",
        hours="Sunday – Thursday · 8:00 AM – 4:00 PM",
        services=(
            "Orientation week coordination",
            "Clubs, societies and student council",
            "Welfare support and hardship referrals",
            "Student complaints and grievance handling",
            "Student handbook and code of conduct",
        ),
        handles=("orientation", "handbook"),
    ),
    Department(
        slug="advising",
        name="Academic Advising",
        tagline="Study plans, courses and progression",
        description=(
            "Academic advisors help you build a study plan that works, choose "
            "electives, manage your credit load and stay on track for "
            "graduation — including when things get difficult."
        ),
        contact_person="Dr. Mohamed Hassan",
        contact_role="Senior Academic Advisor",
        email="advising@greenhopeuniversity.edu.so",
        phone="+252 90 7 000 140",
        location="Faculty Block B, Room 115",
        hours="Sunday – Thursday · 9:00 AM – 4:00 PM (walk-in, or book ahead)",
        services=(
            "First-semester course selection",
            "Study plan and graduation pathway review",
            "Credit load and elective guidance",
            "Academic difficulty and study-support referrals",
            "Progression, repeating and leave-of-absence advice",
        ),
        handles=("course_reg",),
    ),
    Department(
        slug="library",
        name="University Library",
        tagline="Books, e-resources and study space",
        description=(
            "The academic heart of the campus: set texts, past examination "
            "papers, journal databases, quiet study space and the research "
            "support you need for assignments and projects."
        ),
        contact_person="Mr. Yusuf Warsame",
        contact_role="Head Librarian",
        email="library@greenhopeuniversity.edu.so",
        phone="+252 90 7 000 150",
        location="University Library, ground floor desk",
        hours="Sat – Thu · 7:30 AM – 8:00 PM (extended during exams)",
        services=(
            "Library card activation and borrowing",
            "Set texts, reference works and past papers",
            "Off-campus access to journal databases",
            "Group study room booking",
            "Research and referencing support",
        ),
        handles=("library",),
    ),
    Department(
        slug="it",
        name="IT Support & Student Portal",
        tagline="Email, portal access, Wi-Fi and labs",
        description=(
            "Keeps you connected. IT Support activates student email and portal "
            "accounts, resets passwords, runs the campus network and computer "
            "labs, and resolves any technical problem blocking your studies."
        ),
        contact_person="Eng. Sahra Nur",
        contact_role="IT Support Lead",
        email="itsupport@greenhopeuniversity.edu.so",
        phone="+252 90 7 000 160",
        location="Library Building, Room 006 (IT Helpdesk)",
        hours="Sunday – Thursday · 8:00 AM – 5:00 PM",
        services=(
            "Student email account activation",
            "Student Portal password resets and MFA setup",
            "Campus Wi-Fi and network access",
            "Computer lab and printing support",
            "Software and learning-platform troubleshooting",
        ),
        handles=("email_portal",),
    ),
    Department(
        slug="health",
        name="Campus Health Center",
        tagline="Medical check-ups, insurance and first aid",
        description=(
            "On-campus primary care for students and staff. The Health Center "
            "runs the freshman health check, manages student health insurance "
            "enrolment and handles day-to-day illness and injury."
        ),
        contact_person="Dr. Khadija Elmi",
        contact_role="Campus Medical Officer",
        email="health@greenhopeuniversity.edu.so",
        phone="+252 90 7 000 170",
        location="Campus Health Center, opposite the Library",
        hours="Sun – Thu · 8:00 AM – 4:00 PM · emergency line 24/7",
        services=(
            "Freshman medical check-up",
            "Vaccination records and required immunisations",
            "Student health insurance enrolment",
            "First aid and minor injury treatment",
            "Referrals to Garowe general hospitals",
        ),
        handles=("health",),
    ),
    Department(
        slug="hostel",
        name="Hostel & Welfare Office",
        tagline="Accommodation, meals and campus living",
        description=(
            "Manages on-campus accommodation and student welfare: room "
            "allocation, bedding and keys, meal plans, maintenance requests "
            "and general support for students living away from home."
        ),
        contact_person="Mr. Ibrahim Osman",
        contact_role="Hostel & Welfare Coordinator",
        email="hostel@greenhopeuniversity.edu.so",
        phone="+252 90 7 000 180",
        location="Hostel & Welfare Office, near Block C",
        hours="Daily · 7:00 AM – 6:00 PM (warden on call overnight)",
        services=(
            "Hostel application and room allocation",
            "Bedding, keys and room inventory",
            "Meal plan enrolment",
            "Maintenance and repair requests",
            "Off-campus housing advice for commuting students",
        ),
        handles=("hostel",),
    ),
    Department(
        slug="careers",
        name="Career Services",
        tagline="Internships, CVs and employer links",
        description=(
            "Helps you turn your degree into a career. Career Services runs CV "
            "clinics and interview practice, advertises internships and "
            "part-time work, and connects students with employers and alumni."
        ),
        contact_person="Ms. Ayaan Sheikh",
        contact_role="Career Services Officer",
        email="careers@greenhopeuniversity.edu.so",
        phone="+252 90 7 000 190",
        location="Student Centre, Room 108",
        hours="Sunday – Thursday · 9:00 AM – 4:00 PM",
        services=(
            "CV and cover-letter clinics",
            "Internship and attachment placement",
            "Employer talks and recruitment drives",
            "Part-time and vacation work listings",
            "Alumni mentoring network",
        ),
        handles=(),
    ),
)


# ===========================================================================
# Orientation week schedule
# ===========================================================================
@dataclass(frozen=True)
class ScheduleEvent:
    """A single dated event in orientation week."""

    date: str          # ISO date
    day_label: str     # e.g. "Mon 21 Sep"
    time: str
    title: str
    venue: str
    detail: str
    tag: str           # "Mandatory" | "Recommended" | "Social"


ORIENTATION_SCHEDULE: Tuple[ScheduleEvent, ...] = (
    ScheduleEvent(
        date="2026-09-21",
        day_label="Mon 21 Sep",
        time="08:30 – 11:00",
        title="Welcome assembly & official opening",
        venue="Main Auditorium",
        detail=(
            "Rector's welcome address, introduction of faculty deans, and the "
            "campus safety and security briefing."
        ),
        tag="Mandatory",
    ),
    ScheduleEvent(
        date="2026-09-21",
        day_label="Mon 21 Sep",
        time="11:30 – 13:00",
        title="Campus tour & Wi-Fi onboarding",
        venue="Meet at the Main Gate",
        detail=(
            "Guided walk through the faculties, library, health centre and "
            "hostels. Bring your phone to connect to campus Wi-Fi."
        ),
        tag="Recommended",
    ),
    ScheduleEvent(
        date="2026-09-22",
        day_label="Tue 22 Sep",
        time="09:00 – 11:00",
        title="Academic integrity & assessment rules",
        venue="Auditorium Hall B",
        detail=(
            "What counts as plagiarism, how you are assessed, and the grading "
            "and progression rules for your programme."
        ),
        tag="Mandatory",
    ),
    ScheduleEvent(
        date="2026-09-22",
        day_label="Tue 22 Sep",
        time="11:30 – 13:00",
        title="Library induction & e-resource clinic",
        venue="University Library",
        detail=(
            "Library card activation, catalogue search, past papers and "
            "off-campus access to journal databases."
        ),
        tag="Recommended",
    ),
    ScheduleEvent(
        date="2026-09-23",
        day_label="Wed 23 Sep",
        time="09:00 – 12:00",
        title="Faculty meet-and-greet & advisor meetings",
        venue="Faculty Block B",
        detail=(
            "Meet your faculty advisor, agree your first-semester course load "
            "and get your programme study plan."
        ),
        tag="Mandatory",
    ),
    ScheduleEvent(
        date="2026-09-23",
        day_label="Wed 23 Sep",
        time="14:00 – 16:00",
        title="Fees, finance & scholarship briefing",
        venue="Administration Block A",
        detail=(
            "How to pay, instalment options, mobile-money channels and the "
            "scholarships and bursaries available."
        ),
        tag="Recommended",
    ),
    ScheduleEvent(
        date="2026-09-24",
        day_label="Thu 24 Sep",
        time="08:30 – 13:00",
        title="Health checks & insurance enrolment",
        venue="Campus Health Center",
        detail=(
            "Drop-in screening, vaccination review and student health "
            "insurance enrolment. Bring your immunisation records."
        ),
        tag="Mandatory",
    ),
    ScheduleEvent(
        date="2026-09-24",
        day_label="Thu 24 Sep",
        time="14:00 – 16:30",
        title="Clubs, societies & sports fair",
        venue="Student Centre Courtyard",
        detail=(
            "Meet every student club and society, sign up for sports, and "
            "meet your student council representatives."
        ),
        tag="Social",
    ),
    ScheduleEvent(
        date="2026-09-25",
        day_label="Fri 25 Sep",
        time="09:00 – 11:30",
        title="Course registration clinic",
        venue="Computer Lab 1 & 2",
        detail=(
            "Bursar and IT staff on hand while you complete course "
            "registration in the Student Portal. Bring your fee receipt."
        ),
        tag="Mandatory",
    ),
    ScheduleEvent(
        date="2026-09-25",
        day_label="Fri 25 Sep",
        time="12:00 – 14:00",
        title="Freshman welcome lunch & closing",
        venue="Main Auditorium Lawn",
        detail=(
            "Closing remarks, class photograph and lunch with your cohort. "
            "Teaching begins the following Monday."
        ),
        tag="Social",
    ),
)


# ===========================================================================
# Pre-written enquiry templates ("common freshman inquiries")
# ===========================================================================
@dataclass(frozen=True)
class EnquiryTemplate:
    """A ready-to-send email template with pre-filled subject and body."""

    id: str
    label: str
    dept: str
    subject: str
    body: str


ENQUIRY_TEMPLATES: Tuple[EnquiryTemplate, ...] = (
    EnquiryTemplate(
        id="general",
        label="General enquiry about starting at Garowe Campus",
        dept="admissions",
        subject="Freshman enquiry — starting at Garowe Campus",
        body=(
            "Dear Garowe Campus team,\n\n"
            "I am an incoming freshman and I would like to ask about the "
            "following:\n\n"
            "1. \n"
            "2. \n\n"
            "My details:\n"
            "Full name: {name}\n"
            "Student / application ID: {student_id}\n"
            "Programme: {programme}\n"
            "Intended intake: {academic_year}\n\n"
            "Thank you for your help.\n\n"
            "Kind regards,\n{name}\n{phone}\n{email}"
        ),
    ),
    EnquiryTemplate(
        id="documents",
        label="Document submission & registration status",
        dept="admissions",
        subject="Document submission & registration status — {name} ({student_id})",
        body=(
            "Dear Admissions & Registrar,\n\n"
            "I have submitted my registration on the Student Portal and "
            "uploaded my supporting documents. Could you please confirm:\n\n"
            "1. Whether my documents have been received and verified;\n"
            "2. Whether my enrolment number has been issued;\n"
            "3. Any document still outstanding.\n\n"
            "Student ID: {student_id}\n"
            "Programme: {programme}\n\n"
            "I am happy to bring the original documents to the counter if "
            "that is easier.\n\n"
            "Kind regards,\n{name}\n{phone}\n{email}"
        ),
    ),
    EnquiryTemplate(
        id="fees",
        label="Tuition, instalments & payment confirmation",
        dept="finance",
        subject="Tuition payment & instalment plan enquiry — {student_id}",
        body=(
            "Dear Bursar's Office,\n\n"
            "I would like to ask about my tuition and fees for the "
            "{academic_year} academic year:\n\n"
            "1. The total amount due and the payment deadline;\n"
            "2. Whether I am eligible for the two-instalment plan;\n"
            "3. Confirmation that my recent payment has been posted to my account.\n\n"
            "Student ID: {student_id}\n"
            "Programme: {programme}\n\n"
            "Kind regards,\n{name}\n{phone}\n{email}"
        ),
    ),
    EnquiryTemplate(
        id="hostel",
        label="Hostel / dorm allocation request",
        dept="hostel",
        subject="Hostel accommodation request — freshman {name} ({student_id})",
        body=(
            "Dear Hostel & Welfare Office,\n\n"
            "I am an incoming freshman and would like to apply for on-campus "
            "accommodation for the {academic_year} academic year.\n\n"
            "Could you please confirm:\n"
            "1. Whether hostel places are still available;\n"
            "2. The fee and what is included (bedding, meals);\n"
            "3. What I need to bring on move-in day.\n\n"
            "Student ID: {student_id}\n"
            "Programme: {programme}\n"
            "Preferred move-in date: \n\n"
            "Kind regards,\n{name}\n{phone}\n{email}"
        ),
    ),
    EnquiryTemplate(
        id="courses",
        label="Course registration & timetable",
        dept="advising",
        subject="Course registration & timetable — {programme} freshman",
        body=(
            "Dear Academic Advising,\n\n"
            "I am registering for my first semester of {programme} and would "
            "like to confirm my course load.\n\n"
            "1. Are the compulsory courses shown on my portal complete?\n"
            "2. Which electives do you recommend for a first-semester student?\n"
            "3. Could we book a short advising session to review my study plan?\n\n"
            "Student ID: {student_id}\n\n"
            "Kind regards,\n{name}\n{phone}\n{email}"
        ),
    ),
    EnquiryTemplate(
        id="it",
        label="Email / student portal access problem",
        dept="it",
        subject="Portal or email access issue — {student_id}",
        body=(
            "Dear IT Support,\n\n"
            "I am unable to access my university account and would appreciate "
            "your help.\n\n"
            "What I was trying to do: \n"
            "What happens when I try: (error message if any) \n"
            "Student ID: {student_id}\n"
            "Device / browser: \n\n"
            "Please note my activation link may have expired.\n\n"
            "Kind regards,\n{name}\n{phone}\n{email}"
        ),
    ),
    EnquiryTemplate(
        id="health",
        label="Health check & insurance enrolment",
        dept="health",
        subject="Health check & insurance enrolment — freshman appointment",
        body=(
            "Dear Campus Health Center,\n\n"
            "I am a new freshman and would like to complete my health check "
            "and insurance enrolment.\n\n"
            "1. Do I need to book an appointment or may I walk in?\n"
            "2. Which vaccinations or records should I bring?\n"
            "3. What does the student health insurance cover?\n\n"
            "Student ID: {student_id}\n"
            "Preferred day / time: \n\n"
            "Kind regards,\n{name}\n{phone}\n{email}"
        ),
    ),
    EnquiryTemplate(
        id="careers",
        label="Internships, work experience & CV help",
        dept="careers",
        subject="Career Services enquiry — internship opportunities for freshmen",
        body=(
            "Dear Career Services,\n\n"
            "I have just started as a freshman on {programme} and I am keen to "
            "build experience alongside my studies.\n\n"
            "1. What internships or part-time roles are open to first-year students?\n"
            "2. When are your next CV clinic sessions?\n"
            "3. How can I join the alumni mentoring network?\n\n"
            "Student ID: {student_id}\n\n"
            "Kind regards,\n{name}\n{phone}\n{email}"
        ),
    ),
)


# ===========================================================================
# Small helpers
# ===========================================================================
def total_weight() -> int:
    """Sum of every checklist item's weight (used to sanity-check == 100)."""
    return sum(item.weight for item in CHECKLIST_ITEMS)


def item_by_id(item_id: str) -> ChecklistItem | None:
    """Look up a checklist item by its id, or ``None``."""
    return next((item for item in CHECKLIST_ITEMS if item.id == item_id), None)


def department_by_slug(slug: str) -> Department | None:
    """Look up a department by slug, or ``None``."""
    return next((dept for dept in DEPARTMENTS if dept.slug == slug), None)
