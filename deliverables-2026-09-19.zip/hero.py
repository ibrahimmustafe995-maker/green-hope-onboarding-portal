"""Welcome tab — the landing experience for a new freshman.

Layout: a two-panel hero (solid brand panel beside the campus photograph so
text contrast is guaranteed without a scrim), then a welcome message, the
quick-start guide, the key dates, and a map of what the portal contains.
"""

from __future__ import annotations

import streamlit as st

from portal import assets, components as ui
from portal.data import DEPARTMENTS, ORIENTATION_SCHEDULE
from portal.logic import progress
from portal.settings import BRAND, CAMPUS, CONTACT, ORIENTATION, UNIVERSITY

__all__ = ["render"]

# The four steps a freshman should take first, in order.
_QUICK_START = (
    (
        "Register and upload your documents",
        "Complete your enrolment on the Student Portal and upload your "
        "certificates. Bring the originals to Admissions in week one.",
    ),
    (
        "Pay your fees, then activate your portal",
        "Fees release your course registration. Activate your university "
        "email and portal account as soon as the link arrives.",
    ),
    (
        "Come to orientation week",
        "Five days that set you up for the semester — advisor meetings, the "
        "library, the health check and your timetable all happen here.",
    ),
    (
        "Register your courses before 8 October",
        "Confirm your course load with your academic advisor, then register "
        "in the portal and check your status reads 'Registered'.",
    ),
)

# What the visitor will find on each tab.
_PORTAL_MAP = (
    ("Onboarding Checklist", "Ten steps with documents, fees and tips for each."),
    ("Progress", "How far you have come, what is left, and the week's timetable."),
    ("Departments & Contact", "Nine campus offices, each with one-click email."),
)


def _hero() -> str:
    """The two-panel hero block."""
    crest_img = assets.img_tag("crest.png", alt=f"{UNIVERSITY} crest", css_class="ghu-hero__crest")
    media_img = assets.img_tag(
        "campus_hero.png",
        alt=f"{UNIVERSITY} {CAMPUS} campus at golden hour",
    )

    crest_html = crest_img or ""
    media_html = media_img or ""

    return (
        '<div class="ghu-hero">'
        '<div class="ghu-hero__panel">'
        '<div class="ghu-hero__brandrow">'
        f"{crest_html}"
        "<div>"
        f'<p class="ghu-hero__brandname">{ui.esc(UNIVERSITY)}</p>'
        f'<p class="ghu-hero__brandsub">{ui.esc(CAMPUS)}</p>'
        "</div></div>"
        f'<p class="ghu-eyebrow ghu-eyebrow--light">{ui.esc(BRAND["motto"])}</p>'
        f'<p class="ghu-hero__title">Welcome to {ui.esc(CAMPUS)}</p>'
        '<p class="ghu-hero__lede">'
        "Congratulations on your place — and welcome to the Green Hope family. "
        "This portal walks you through everything you need to do before "
        "teaching begins, in the right order, with the documents, fees and "
        "contacts for every step."
        "</p>"
        '<div class="ghu-hero__chips">'
        f'<span class="ghu-hero__chip">Academic year {ui.esc(ORIENTATION["academic_year"])}</span>'
        '<span class="ghu-hero__chip">Orientation · 21–25 Sep 2026</span>'
        f'<span class="ghu-hero__chip">{len(DEPARTMENTS)} campus offices</span>'
        "</div>"
        "</div>"
        f'<div class="ghu-hero__media">{media_html}</div>'
        "</div>"
    )


def _welcome_message() -> str:
    """The welcome letter, plus the campus hours/contact strip."""
    body = (
        f'<p class="ghu-eyebrow">A message for our new students</p>'
        f'<p class="ghu-h2">You belong here.</p>'
        f'<p class="ghu-p">'
        f"Starting university is a big step, and it is normal to feel both "
        f"excited and unsure about what comes first. We built this portal so "
        f"you never have to guess. Begin with the "
        f"<span class=\"ghu-strong\">Onboarding Checklist</span> — it lists "
        f"every step in the order that works, tells you which office to visit, "
        f"what to bring and what it costs. Your progress is saved as you go, so "
        f"you can work through it over several days."
        f"</p>"
        f'<p class="ghu-p">'
        f"If anything is unclear, contact any campus office directly from the "
        f"<span class=\"ghu-strong\">Departments &amp; Contact</span> tab. "
        f"For anything general, write to the campus front desk at "
        f'<span class="ghu-strong">{ui.esc(CONTACT["primary_email"])}</span> — '
        f"we answer every message."
        f"</p>"
        f'<p class="ghu-p" style="margin-bottom:0;">'
        f"Karibu, and welcome to Garowe."
        f"</p>"
        f'<div class="ghu-dl" style="margin-top:.9rem;">'
        f'<div class="ghu-dl__row"><div class="ghu-dl__k">Office</div>'
        f'<div class="ghu-dl__v">{ui.esc(CONTACT["office"])}</div></div>'
        f'<div class="ghu-dl__row"><div class="ghu-dl__k">Opening hours</div>'
        f'<div class="ghu-dl__v">{ui.esc(CONTACT["hours"])}</div></div>'
        f'<div class="ghu-dl__row"><div class="ghu-dl__k">Switchboard</div>'
        f'<div class="ghu-dl__v">{ui.esc(CONTACT["switchboard"])}</div></div>'
        f"</div>"
    )
    return ui.card(body)


def _quick_start() -> str:
    """The numbered quick-start guide."""
    steps = "".join(
        '<div class="ghu-step">'
        f'<div class="ghu-step__num">{n}</div>'
        f'<p class="ghu-step__title">{ui.esc(title)}</p>'
        f'<p class="ghu-step__text">{ui.esc(text)}</p>'
        f"</div>"
        for n, (title, text) in enumerate(_QUICK_START, start=1)
    )
    return f'<div class="ghu-steps-grid">{steps}</div>'


def _key_dates() -> str:
    """Three deadline cards, driven from config."""
    items = (
        ("Registration closes", ORIENTATION["registration_deadline"], "Admissions & Registrar"),
        ("Tuition & fees due", ORIENTATION["fees_deadline"], "Finance / Bursar"),
        ("Course registration closes", ORIENTATION["course_registration_deadline"], "Academic Advising"),
    )
    cards = ""
    for label, iso, owner in items:
        due = progress.parse_iso(iso)
        pretty = due.strftime("%-d %b %Y") if due else iso
        days = (due - progress.as_date(None)).days if due else None
        if days is None:
            note = owner
        elif days < 0:
            note = f"Passed · {owner}"
        elif days == 0:
            note = f"Today · {owner}"
        else:
            note = f"in {days} days · {owner}"

        cards += ui.card(
            f'<p class="ghu-kpi__label">{ui.esc(label)}</p>'
            f'<p class="ghu-h3" style="font-family:ui-monospace,Menlo,monospace;'
            f'font-size:1.05rem;">{ui.esc(pretty)}</p>'
            f'<p class="ghu-small" style="margin:0;">{ui.esc(note)}</p>',
            variant="sand flat",
        )
    return f'<div class="ghu-grid3">{cards}</div>'


def _portal_map() -> str:
    """A short guide to what each tab contains."""
    rows = ""
    for name, desc in _PORTAL_MAP:
        rows += (
            f'<div class="ghu-dl__row">'
            f'<div class="ghu-dl__k" style="flex:0 0 40%;">{ui.esc(name)}</div>'
            f'<div class="ghu-dl__v">{ui.esc(desc)}</div>'
            f"</div>"
        )
    first_day = ORIENTATION_SCHEDULE[0]
    return ui.card(
        f'<p class="ghu-h3">How to use this portal</p>'
        f'<p class="ghu-small" style="margin-bottom:.4rem;">'
        f"Work through the tabs in order. Your progress is saved automatically."
        f"</p>"
        f'<div class="ghu-dl">{rows}</div>'
        f'<p class="ghu-small" style="margin:.8rem 0 0 0;">'
        f"Orientation opens on {ui.esc(first_day.day_label)} with the "
        f"{ui.esc(first_day.title.lower())} at {ui.esc(first_day.venue)}."
        f"</p>"
    )


def render() -> None:
    """Draw the Welcome tab."""
    st.markdown(_hero(), unsafe_allow_html=True)

    caution = (
        f'<p class="ghu-eyebrow">Start here</p>'
        f'<p class="ghu-h2">Your first four steps</p>'
        f'<p class="ghu-section__sub">'
        f"Do these in order — each one unlocks the next."
        f"</p>"
    )
    st.markdown(f'<div class="ghu-section">{caution}</div>', unsafe_allow_html=True)
    st.markdown(_quick_start(), unsafe_allow_html=True)

    st.markdown(
        f'<div class="ghu-section">{ui.section_head("Key dates for your diary", "The three deadlines that matter most in your first fortnight.")}</div>',
        unsafe_allow_html=True,
    )
    st.markdown(_key_dates(), unsafe_allow_html=True)

    left, right = st.columns([1.35, 1], gap="medium")
    with left:
        st.markdown(
            f'<div class="ghu-section">{ui.section_head("Welcome from Garowe Campus")}</div>',
            unsafe_allow_html=True,
        )
        st.markdown(_welcome_message(), unsafe_allow_html=True)
    with right:
        st.markdown(
            f'<div class="ghu-section">{ui.section_head("Using the portal")}</div>',
            unsafe_allow_html=True,
        )
        st.markdown(_portal_map(), unsafe_allow_html=True)

    st.markdown(
        f'<div class="ghu-foot">'
        f"{ui.esc(UNIVERSITY)} · {ui.esc(CAMPUS)} · "
        f"{ui.esc(BRAND['motto'])}<br/>"
        f"General enquiries: "
        f'<span class="ghu-mono">{ui.esc(CONTACT["primary_email"])}</span> · '
        f"{ui.esc(CONTACT['switchboard'])} · {ui.esc(CONTACT['hours'])}"
        f"</div>",
        unsafe_allow_html=True,
    )
