"""Green Hope University — Garowe Campus
Freshman Orientation & Welcome Portal
===================================================================

Entry point. Run with::

    pip install -r requirements.txt
    streamlit run app.py

Architecture
------------
``app.py`` is deliberately thin: it configures the page, draws the sidebar,
then hands off to one of four view modules. All content lives in
``portal/data.py``, all branding in ``config.yaml``, and all presentation in
``portal/styles.py`` + ``portal/components.py`` — so the app can be
re-skinned for another campus without touching a view.

Progress state is held in ``st.session_state`` and mirrored to
``state/progress.json`` (see ``portal/state.py``), so a student's ticks
survive closing the tab.
"""

from __future__ import annotations

import streamlit as st

from portal import assets, components as ui, state, styles
from portal.data import DEPARTMENTS, ENQUIRY_TEMPLATES, PHASES, total_weight
from portal.logic import progress
from portal.settings import (
    BRAND,
    CAMPUS,
    CONTACT,
    ORIENTATION,
    PRIMARY_EMAIL,
    UNIVERSITY,
)
from portal.views import checklist, directory, hero, progress as progress_view

# ---------------------------------------------------------------------------
# Page configuration — must be the first Streamlit call in the script.
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title=f"{UNIVERSITY} — {CAMPUS} Freshman Portal",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
)


def _bootstrap() -> None:
    """One-time start-up work: static assets + session state."""
    # Mirror assets/ into static/ so replacements are picked up without a
    # manual copy step (Streamlit serves static/ at app/static/<file>).
    assets.sync_static_dir()
    state.init_state()


def _sidebar() -> None:
    """Brand block, demo controls, progress at a glance and contact details."""
    with st.sidebar:
        # --- Brand ---------------------------------------------------------
        crest = assets.img_tag(
            "crest.png",
            alt=f"{UNIVERSITY} crest",
            style="width:74px;height:74px;object-fit:contain;display:block;margin:0 auto .6rem auto;",
        )
        if crest:
            st.markdown(crest, unsafe_allow_html=True)
        st.markdown(
            f'<p style="text-align:center;font-family:Georgia,serif;font-size:1.02rem;'
            f'font-weight:700;color:#14261E;margin:0;">{ui.esc(UNIVERSITY)}</p>'
            f'<p style="text-align:center;font-size:.72rem;font-weight:800;'
            f'letter-spacing:.14em;text-transform:uppercase;color:#C9A227;'
            f'margin:.15rem 0 .1rem 0;">{ui.esc(CAMPUS)}</p>'
            f'<p style="text-align:center;font-size:.76rem;color:#5C7069;margin:0 0 .2rem 0;">'
            f"Freshman Orientation Portal</p>"
            f'<p style="text-align:center;font-size:.72rem;color:#5C7069;margin:0;">'
            f"Academic year {ui.esc(ORIENTATION['academic_year'])}</p>",
            unsafe_allow_html=True,
        )
        st.markdown("---")

        # --- Progress at a glance -----------------------------------------
        summary = progress.summarize(state.completed_ids())
        st.markdown(
            f'<p class="ghu-kpi__label" style="margin-bottom:.35rem;">Your progress</p>',
            unsafe_allow_html=True,
        )
        st.markdown(
            ui.bar_row("", summary.percent, f"{summary.percent:.0f}%"),
            unsafe_allow_html=True,
        )
        st.markdown(
            f'<p class="ghu-small" style="margin:.35rem 0 .8rem 0;">'
            f"{summary.completed_count} of {summary.total_count} steps complete · "
            f"{ui.esc(summary.status)}</p>",
            unsafe_allow_html=True,
        )

        # --- Student profile ------------------------------------------------
        st.markdown(
            f'<p class="ghu-kpi__label" style="margin-bottom:.3rem;">Your details</p>',
            unsafe_allow_html=True,
        )
        profile = state.get_student()
        # No value= on these inputs: the widget keys are seeded
        # authoritatively by state.sync_widget_keys() during _bootstrap, and
        # passing value= as well makes Streamlit warn that the widget "was
        # created with a default value but also had its value set via the
        # Session State API". The keys are the single source of truth.
        st.text_input("Full name", key="pf_name",
                      placeholder="e.g. Amina Yusuf Abdi")
        st.text_input("Student / application ID",
                      key="pf_sid", placeholder="GHU-2026-10482")
        st.text_input("Programme", key="pf_prog",
                      placeholder="e.g. BSc Computer Science")

        # Write widget edits back into the profile.
        #
        # Read the session_state widget keys directly rather than comparing
        # against the value= passed above: once a widget key exists Streamlit
        # ignores value= entirely, so a stale comparison would see "blank
        # field vs. stored name" and blank a profile that was just loaded
        # programmatically (e.g. by the demo button).
        edits = {
            "name": st.session_state.get("pf_name", ""),
            "student_id": st.session_state.get("pf_sid", ""),
            "programme": st.session_state.get("pf_prog", ""),
        }
        if any(edits[field] != profile.get(field, "") for field in edits):
            state.update_student(**edits)
            profile = state.get_student()

        # One-shot confirmation for the actions below. A toast would already
        # have faded by the time the page settles, so this persists until the
        # next interaction.
        flash = st.session_state.get(state.FLASH_KEY)
        if flash:
            del st.session_state[state.FLASH_KEY]
            st.success(flash)

        # on_click callbacks, deliberately NOT `if st.button(): ...`.
        # A callback runs BEFORE the script body, so it may legitimately
        # rewrite the pf_* / chk_* widget keys; doing the same work inside an
        # `if st.button(...)` block — which executes after those widgets have
        # been instantiated — raises StreamlitAPIException. Streamlit reruns
        # automatically after a callback, so no explicit st.rerun() is needed.
        st.button(
            "Load demo student",
            use_container_width=True,
            key="load_demo",
            on_click=state.load_demo_student,
        )
        st.button(
            "Reset my progress",
            use_container_width=True,
            key="reset_prog",
            on_click=state.reset_progress,
        )

        st.markdown("---")

        # --- Primary contact -------------------------------------------------
        st.markdown(
            f'<p class="ghu-kpi__label" style="margin-bottom:.3rem;">Primary contact</p>'
            f'<p style="font-family:ui-monospace,Menlo,monospace;font-size:.78rem;'
            f'color:#0A5238;word-break:break-all;margin:0 0 .3rem 0;">'
            f"{ui.esc(PRIMARY_EMAIL)}</p>"
            f'<p class="ghu-small" style="margin:0 0 .55rem 0;">'
            f"{ui.esc(CONTACT['office'])}<br/>{ui.esc(CONTACT['hours'])}</p>"
            f'<a class="ghu-btn ghu-btn--primary" style="width:100%;text-align:center;" '
            f'href="mailto:{ui.esc(PRIMARY_EMAIL)}" target="_blank" rel="noopener noreferrer">'
            f"Email the campus</a>",
            unsafe_allow_html=True,
        )

        st.markdown(
            f'<p class="ghu-small" style="margin-top:1rem;color:#5C7069;">'
            f"{ui.esc(BRAND['motto'])} · est. {ui.esc(BRAND['established'])}</p>",
            unsafe_allow_html=True,
        )


def _header() -> None:
    """Compact page header above the tabs."""
    st.markdown(
        f'<div style="display:flex;flex-wrap:wrap;gap:.5rem;align-items:baseline;'
        f'border-bottom:1px solid #DFD8C8;padding-bottom:.6rem;margin-bottom:1rem;">'
        f'<span class="ghu-eyebrow" style="margin:0;">{ui.esc(UNIVERSITY)} · {ui.esc(CAMPUS)}</span>'
        f'<span class="ghu-small" style="margin-left:auto;">'
        f"Orientation {ui.esc(ORIENTATION['week_start'])} – {ui.esc(ORIENTATION['week_end'])} · "
        f"{ui.esc(ORIENTATION['timezone'])}</span>"
        f"</div>",
        unsafe_allow_html=True,
    )


def main() -> None:
    """Assemble and run the portal."""
    _bootstrap()
    styles.inject_css()
    _sidebar()
    _header()

    tab_welcome, tab_checklist, tab_progress, tab_directory = st.tabs(
        [
            "🏠  Welcome",
            "✅  Onboarding Checklist",
            "📊  Progress",
            "📇  Departments & Contact",
        ]
    )

    with tab_welcome:
        hero.render()
    with tab_checklist:
        checklist.render()
    with tab_progress:
        progress_view.render()
    with tab_directory:
        directory.render()

    # Defensive: surfaces a config/data mismatch in the app rather than in a
    # stack trace. Weights must total 100 for the percentage to be honest.
    if total_weight() != 100:  # pragma: no cover - guard only
        st.warning(
            f"Checklist weights total {total_weight()} instead of 100 — "
            f"check portal/data.py."
        )


if __name__ == "__main__":
    main()
