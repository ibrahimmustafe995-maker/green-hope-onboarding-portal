"""The portal's CSS design system.

One place defines the visual language — palette, type scale, spacing, cards,
badges, buttons, timeline and progress elements — and ``inject_css()`` pushes
it into the Streamlit page once per run.

Using ``string.Template`` (``$primary``) rather than an f-string keeps the
CSS readable: every brace in the stylesheet stays a literal brace, so there
is no escaping noise to get wrong.

Colour discipline: one dominant brand colour (deep emerald), one accent
(gold) and a small set of warm neutrals (sand / cream / ink). No gradients —
depth comes from borders, soft shadows and tinted surfaces instead.
"""

from __future__ import annotations

from string import Template
from typing import Final

from portal.settings import CONTACT, THEME

__all__ = ["inject_css", "css", "FONT_DISPLAY", "FONT_BODY"]

# Editorial serif for display type, humanist sans for everything else.
# Both are system stacks, so the portal needs no external font fetch and
# still looks right offline.
FONT_DISPLAY: Final[str] = (
    '"Iowan Old Style", "Palatino Linotype", Palatino, "Book Antiqua", '
    "Georgia, 'Times New Roman', serif"
)
FONT_BODY: Final[str] = (
    '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", '
    "Arial, 'Noto Sans', sans-serif"
)


_CSS_TEMPLATE: Final[str] = Template(
    """
/* =====================================================================
   Green Hope University — Garowe Campus | design system
   ===================================================================== */

:root {
  --ghu-primary: $primary;
  --ghu-primary-dark: $primary_dark;
  --ghu-primary-light: $primary_light;
  --ghu-primary-soft: $primary_soft;
  --ghu-gold: $gold;
  --ghu-gold-light: $gold_light;
  --ghu-sand: $sand;
  --ghu-cream: $cream;
  --ghu-ink: $ink;
  --ghu-muted: $muted;
  --ghu-border: $border;
  --ghu-success: $success;
  --ghu-warning: $warning;
  --ghu-danger: $danger;
  --ghu-radius: 14px;
  --ghu-radius-sm: 8px;
  --ghu-shadow: 0 1px 2px rgba(20, 38, 30, .05), 0 6px 18px rgba(20, 38, 30, .05);
  --ghu-shadow-lg: 0 2px 4px rgba(20, 38, 30, .06), 0 16px 40px rgba(20, 38, 30, .09);
}

/* ---------------------------------------------------------------------
   Streamlit chrome — strip the developer UI, widen the canvas.
   --------------------------------------------------------------------- */
#MainMenu, footer, [data-testid="stToolbar"], [data-testid="stDecoration"] {
  display: none !important;
}
[data-testid="stAppViewContainer"], [data-testid="stMain"] { background: $cream; }
[data-testid="stHeader"] { background: transparent; box-shadow: none; }
[data-testid="stSidebar"] {
  background: $sand;
  border-right: 1px solid $border;
}
[data-testid="stSidebar"] .block-container { padding-top: 1.5rem; }
.block-container, [data-testid="stMainBlockContainer"] {
  max-width: 1200px;
  padding-top: 1.1rem !important;
  padding-bottom: 3.5rem !important;
}

/* Tabs — quiet underline styling that matches the brand. */
[data-baseweb="tab-list"] {
  gap: .25rem;
  border-bottom: 1px solid $border;
  background: transparent;
}
[data-baseweb="tab"] {
  font-family: $font_body;
  font-weight: 600;
  font-size: .92rem;
  color: $muted;
  letter-spacing: .01em;
  padding: .55rem .95rem;
  background: transparent;
}
[data-baseweb="tab"][aria-selected="true"] { color: $primary; }
[data-baseweb="tab-highlight"] { background: $primary !important; height: 2.5px; }
[data-baseweb="tab-border"] { display: none; }

/* ---------------------------------------------------------------------
   Type
   --------------------------------------------------------------------- */
.ghu-body, .ghu-card, .ghu-kpi, .ghu-dept, .ghu-check, .ghu-note {
  font-family: $font_body;
  color: $ink;
}
.ghu-eyebrow {
  font-family: $font_body;
  font-size: .7rem;
  font-weight: 800;
  letter-spacing: .16em;
  text-transform: uppercase;
  color: $gold;
  margin: 0 0 .55rem 0;
}
.ghu-eyebrow--light { color: $gold_light; }
.ghu-h1 {
  font-family: $font_display;
  font-size: 2.5rem;
  line-height: 1.1;
  font-weight: 700;
  letter-spacing: -.015em;
  margin: 0 0 .5rem 0;
  color: $ink;
}
.ghu-h2 {
  font-family: $font_display;
  font-size: 1.6rem;
  line-height: 1.22;
  font-weight: 700;
  letter-spacing: -.01em;
  margin: 0 0 .4rem 0;
  color: $ink;
}
.ghu-h3 {
  font-family: $font_body;
  font-size: 1.02rem;
  font-weight: 700;
  margin: 0 0 .3rem 0;
  color: $ink;
}
.ghu-lede {
  font-family: $font_body;
  font-size: 1.03rem;
  line-height: 1.62;
  color: $muted;
  margin: 0 0 .8rem 0;
}
.ghu-p { font-family: $font_body; font-size: .93rem; line-height: 1.68; color: $muted; margin: 0 0 .7rem 0; }
.ghu-small { font-family: $font_body; font-size: .82rem; line-height: 1.55; color: $muted; }
.ghu-strong { color: $ink; font-weight: 700; }
.ghu-mono {
  font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
  font-size: .84rem;
}

/* ---------------------------------------------------------------------
   Hero — a solid brand panel beside the photograph (never text-on-image,
   which keeps contrast guaranteed and avoids a scrim gradient).
   --------------------------------------------------------------------- */
.ghu-hero {
  display: flex;
  flex-wrap: wrap;
  border-radius: var(--ghu-radius);
  overflow: hidden;
  box-shadow: var(--ghu-shadow-lg);
  border: 1px solid $border;
  background: $primary_dark;
  margin: 0 0 1.5rem 0;
}
.ghu-hero__panel {
  flex: 1 1 430px;
  min-width: 320px;
  background: $primary_dark;
  padding: 2.1rem 2rem 2rem 2rem;
  color: #FFFDF8;
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.ghu-hero__media {
  flex: 1 1 420px;
  min-width: 300px;
  min-height: 300px;
  background: $primary_dark url('$hero_url') center/cover no-repeat;
  position: relative;
}
.ghu-hero__media img { width: 100%; height: 100%; object-fit: cover; display: block; min-height: 300px; }
.ghu-hero__brandrow { display: flex; align-items: center; gap: .85rem; margin-bottom: 1.15rem; }
.ghu-hero__crest {
  width: 62px; height: 62px; border-radius: 50%;
  background: #FFFDF8; padding: 5px; flex: 0 0 62px;
  box-shadow: 0 2px 10px rgba(0,0,0,.28);
  object-fit: contain;
}
.ghu-hero__brandname {
  font-family: $font_display; font-size: 1.1rem; font-weight: 700;
  letter-spacing: .01em; color: #FFFDF8; line-height: 1.25; margin: 0;
}
.ghu-hero__brandsub {
  font-family: $font_body; font-size: .75rem; font-weight: 600;
  letter-spacing: .13em; text-transform: uppercase; color: $gold; margin: .18rem 0 0 0;
}
.ghu-hero__title {
  font-family: $font_display; font-size: 2.35rem; line-height: 1.1;
  font-weight: 700; letter-spacing: -.018em; margin: 0 0 .6rem 0; color: #FFFDF8;
}
.ghu-hero__lede {
  font-family: $font_body; font-size: .97rem; line-height: 1.66;
  color: rgba(255, 253, 248, .84); margin: 0 0 1.15rem 0; max-width: 46ch;
}
.ghu-hero__chips { display: flex; flex-wrap: wrap; gap: .45rem; }
.ghu-hero__chip {
  font-family: $font_body; font-size: .74rem; font-weight: 700;
  letter-spacing: .05em; text-transform: uppercase;
  color: #FFFDF8; background: rgba(255,255,255,.13);
  border: 1px solid rgba(255,255,255,.26);
  padding: .32rem .7rem; border-radius: 999px;
}

/* ---------------------------------------------------------------------
   Section headings
   --------------------------------------------------------------------- */
.ghu-section { margin: 2.1rem 0 0 0; }
.ghu-section__head { border-bottom: 2px solid $primary; padding-bottom: .55rem; margin-bottom: 1.1rem; }
.ghu-section__head .ghu-h2 { margin-bottom: .15rem; }
.ghu-section__sub { font-family: $font_body; font-size: .88rem; color: $muted; margin: 0; }

/* ---------------------------------------------------------------------
   KPI tiles
   --------------------------------------------------------------------- */
.ghu-kpis { display: flex; flex-wrap: wrap; gap: .8rem; margin: 0 0 .4rem 0; }
.ghu-kpi {
  flex: 1 1 165px; min-width: 150px;
  background: #FFFFFF; border: 1px solid $border;
  border-top: 3px solid $primary;
  border-radius: var(--ghu-radius-sm);
  padding: .95rem 1rem .9rem 1rem;
  box-shadow: var(--ghu-shadow);
}
.ghu-kpi--gold { border-top-color: $gold; }
.ghu-kpi--warning { border-top-color: $warning; }
.ghu-kpi__label {
  font-family: $font_body; font-size: .68rem; font-weight: 800;
  letter-spacing: .12em; text-transform: uppercase; color: $muted; margin: 0 0 .3rem 0;
}
.ghu-kpi__value {
  font-family: $font_display; font-size: 1.95rem; font-weight: 700;
  line-height: 1.05; color: $primary_dark; margin: 0;
}
.ghu-kpi__value--gold { color: $gold; }
.ghu-kpi__value--warning { color: $warning; }
.ghu-kpi__note { font-family: $font_body; font-size: .76rem; color: $muted; margin: .3rem 0 0 0; }

/* ---------------------------------------------------------------------
   Cards
   --------------------------------------------------------------------- */
.ghu-card {
  background: #FFFFFF; border: 1px solid $border;
  border-radius: var(--ghu-radius); padding: 1.25rem 1.4rem;
  box-shadow: var(--ghu-shadow); margin: 0 0 .9rem 0;
}
.ghu-card--sand { background: $sand; border-color: $border; }
.ghu-card--light { background: $primary_light; border-color: $primary_soft; }
.ghu-card--gold { background: $gold_light; border-color: #EBD9A6; }
.ghu-card--flat { box-shadow: none; }
.ghu-card__head { display: flex; align-items: flex-start; justify-content: space-between; gap: .8rem; margin-bottom: .5rem; flex-wrap: wrap; }

/* ---------------------------------------------------------------------
   Chips, badges, pills
   --------------------------------------------------------------------- */
.ghu-chip {
  display: inline-block; font-family: $font_body;
  font-size: .7rem; font-weight: 700; letter-spacing: .06em; text-transform: uppercase;
  padding: .26rem .6rem; border-radius: 999px;
  background: $primary_light; color: $primary_dark; border: 1px solid $primary_soft;
  margin: 0 .3rem .3rem 0;
}
.ghu-chip--gold { background: $gold_light; color: #7A6110; border-color: #EBD9A6; }
.ghu-chip--grey { background: $sand; color: $muted; border-color: $border; }
.ghu-chip--success { background: #E4F3EC; color: $success; border-color: #BEE0D0; }
.ghu-chip--warning { background: #FBEFDD; color: #8A5410; border-color: #EED9B8; }
.ghu-chip--danger { background: #F8E6E3; color: $danger; border-color: #EECBC5; }
.ghu-chip--plain { text-transform: none; letter-spacing: .01em; font-weight: 600; }

/* ---------------------------------------------------------------------
   Progress: bar, ring caption, legend
   --------------------------------------------------------------------- */
.ghu-bar { width: 100%; height: 10px; background: $sand; border-radius: 999px; overflow: hidden; border: 1px solid $border; }
.ghu-bar__fill { height: 100%; background: $primary; border-radius: 999px 0 0 999px; }
.ghu-bar--thin { height: 7px; }
.ghu-bar--gold .ghu-bar__fill { background: $gold; }
.ghu-barrow { display: flex; align-items: center; gap: .7rem; margin: .3rem 0; }
.ghu-barrow__label { flex: 0 0 34%; font-family: $font_body; font-size: .84rem; font-weight: 600; color: $ink; }
.ghu-barrow__track { flex: 1 1 auto; }
.ghu-barrow__val { flex: 0 0 auto; font-family: $font_body; font-size: .82rem; font-weight: 700; color: $muted; min-width: 4.2rem; text-align: right; }
.ghu-legend { display: flex; flex-wrap: wrap; gap: .9rem; margin-top: .6rem; }
.ghu-legend__item { font-family: $font_body; font-size: .8rem; color: $muted; display: flex; align-items: center; gap: .38rem; }
.ghu-dot { width: 10px; height: 10px; border-radius: 50%; display: inline-block; }
.ghu-dot--done { background: $primary; }
.ghu-dot--todo { background: $border; }
.ghu-dot--gold { background: $gold; }

/* ---------------------------------------------------------------------
   Primary contact card — the hero of the directory
   --------------------------------------------------------------------- */
.ghu-primary {
  background: $primary_dark; color: #FFFDF8;
  border-radius: var(--ghu-radius); padding: 1.5rem 1.6rem;
  box-shadow: var(--ghu-shadow-lg); margin: 0 0 1.1rem 0;
  border-left: 6px solid $gold;
}
.ghu-primary__label {
  font-family: $font_body; font-size: .7rem; font-weight: 800;
  letter-spacing: .16em; text-transform: uppercase; color: $gold; margin: 0 0 .45rem 0;
}
.ghu-primary__email {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 1.28rem; font-weight: 700; color: #FFFDF8;
  word-break: break-all; margin: 0 0 .55rem 0; line-height: 1.35;
}
.ghu-primary__meta { display: flex; flex-wrap: wrap; gap: 1.4rem; margin: .9rem 0 0 0; }
.ghu-primary__meta div { font-family: $font_body; font-size: .83rem; color: rgba(255,253,248,.82); }
.ghu-primary__meta b { display: block; font-size: .68rem; letter-spacing: .11em; text-transform: uppercase; color: $gold; margin-bottom: .15rem; }

/* ---------------------------------------------------------------------
   Buttons (real anchors, so a mailto click needs no server round-trip)
   --------------------------------------------------------------------- */
.ghu-btn {
  display: inline-block; font-family: $font_body; font-size: .85rem;
  font-weight: 700; letter-spacing: .01em; text-decoration: none !important;
  padding: .52rem 1rem; border-radius: 999px; border: 1px solid transparent;
  cursor: pointer; transition: transform .12s ease, background .12s ease;
}
.ghu-btn:hover { transform: translateY(-1px); }
.ghu-btn--primary { background: $primary; color: #FFFFFF !important; }
.ghu-btn--primary:hover { background: $primary_dark; }
.ghu-btn--gold { background: $gold; color: #2B2000 !important; }
.ghu-btn--gold:hover { background: #B08C1C; }
.ghu-btn--ghost { background: transparent; color: $primary !important; border-color: $primary_soft; }
.ghu-btn--ghost:hover { background: $primary_light; }
.ghu-btn--onDark { background: rgba(255,255,255,.14); color: #FFFDF8 !important; border-color: rgba(255,255,255,.34); }
.ghu-btn--onDark:hover { background: rgba(255,255,255,.24); }
.ghu-btn--danger { background: transparent; color: $danger !important; border-color: #EECBC5; }
.ghu-btnrow { display: flex; flex-wrap: wrap; gap: .5rem; margin-top: .7rem; }

/* ---------------------------------------------------------------------
   Department cards
   --------------------------------------------------------------------- */
.ghu-dept {
  background: #FFFFFF; border: 1px solid $border; border-left: 4px solid $primary;
  border-radius: var(--ghu-radius-sm); padding: 1.1rem 1.2rem;
  box-shadow: var(--ghu-shadow); margin: 0 0 .8rem 0; height: 100%;
}
.ghu-dept__name { font-family: $font_display; font-size: 1.18rem; font-weight: 700; margin: 0 0 .12rem 0; color: $ink; }
.ghu-dept__tag { font-family: $font_body; font-size: .76rem; font-weight: 700; letter-spacing: .07em; text-transform: uppercase; color: $gold; margin: 0 0 .55rem 0; }
.ghu-dept__person { font-family: $font_body; font-size: .89rem; color: $ink; margin: 0 0 .1rem 0; }
.ghu-dept__role { font-family: $font_body; font-size: .8rem; color: $muted; margin: 0 0 .7rem 0; }
.ghu-dept__mail {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: .82rem; color: $primary_dark; word-break: break-all;
}
.ghu-dept__svc { font-family: $font_body; font-size: .84rem; color: $muted; margin: .25rem 0 0 0; padding-left: 1.05rem; }
.ghu-dept__svc li { margin-bottom: .16rem; }

/* ---------------------------------------------------------------------
   Checklist rows
   --------------------------------------------------------------------- */
.ghu-check__meta { display: flex; flex-wrap: wrap; gap: .35rem; margin: .35rem 0 .45rem 0; }
.ghu-check__summary { font-family: $font_body; font-size: .88rem; line-height: 1.6; color: $muted; margin: 0; }
.ghu-steps { font-family: $font_body; font-size: .87rem; line-height: 1.62; color: $ink; margin: .3rem 0 .8rem 0; padding-left: 1.15rem; }
.ghu-steps li { margin-bottom: .3rem; }
.ghu-note {
  background: $gold_light; border-left: 3px solid $gold;
  padding: .6rem .8rem; border-radius: 0 var(--ghu-radius-sm) var(--ghu-radius-sm) 0;
  font-size: .85rem; line-height: 1.6; color: #5C4A0E; margin: .6rem 0 0 0;
}
.ghu-dl { margin: .35rem 0 0 0; }
.ghu-dl__row { display: flex; flex-wrap: wrap; gap: .5rem; padding: .28rem 0; border-bottom: 1px dashed $border; }
.ghu-dl__row:last-child { border-bottom: none; }
.ghu-dl__k { flex: 0 0 34%; font-family: $font_body; font-size: .78rem; font-weight: 800; letter-spacing: .07em; text-transform: uppercase; color: $muted; }
.ghu-dl__v { flex: 1 1 auto; font-family: $font_body; font-size: .85rem; color: $ink; }

/* ---------------------------------------------------------------------
   Orientation timeline
   --------------------------------------------------------------------- */
.ghu-timeline { position: relative; margin: .3rem 0 0 .35rem; padding-left: 1.5rem; }
.ghu-timeline::before {
  content: ""; position: absolute; left: 5px; top: .35rem; bottom: .35rem;
  width: 2px; background: $border;
}
.ghu-ev { position: relative; padding: 0 0 1.15rem 0; }
.ghu-ev::before {
  content: ""; position: absolute; left: -1.5rem; top: .32rem;
  width: 12px; height: 12px; border-radius: 50%;
  background: $primary; border: 2.5px solid $cream; box-shadow: 0 0 0 2px $primary_soft;
}
.ghu-ev--mandatory::before { background: $primary; box-shadow: 0 0 0 2px $primary_soft; }
.ghu-ev--recommended::before { background: $gold; box-shadow: 0 0 0 2px #EBD9A6; }
.ghu-ev--social::before { background: $sand; box-shadow: 0 0 0 2px $border; }
.ghu-ev__when { font-family: $font_body; font-size: .72rem; font-weight: 800; letter-spacing: .1em; text-transform: uppercase; color: $gold; margin: 0 0 .18rem 0; }
.ghu-ev__title { font-family: $font_body; font-size: .96rem; font-weight: 700; color: $ink; margin: 0 0 .18rem 0; }
.ghu-ev__detail { font-family: $font_body; font-size: .85rem; line-height: 1.6; color: $muted; margin: 0; }
.ghu-ev__venue { font-family: $font_body; font-size: .79rem; font-weight: 600; color: $primary; margin: .22rem 0 0 0; }

/* ---------------------------------------------------------------------
   Misc
   --------------------------------------------------------------------- */
.ghu-rule { height: 1px; background: $border; border: none; margin: 1.6rem 0; }
.ghu-foot {
  font-family: $font_body; font-size: .78rem; line-height: 1.65; color: $muted;
  border-top: 1px solid $border; margin-top: 2.4rem; padding-top: 1rem;
}
.ghu-empty {
  font-family: $font_body; font-size: .9rem; color: $muted; text-align: center;
  padding: 1.6rem 1rem; background: $sand; border: 1px dashed $border;
  border-radius: var(--ghu-radius-sm);
}
.ghu-split { display: flex; flex-wrap: wrap; gap: 1rem; }
.ghu-split > * { flex: 1 1 300px; min-width: 260px; }

/* ---------------------------------------------------------------------
   Quick-start steps & auto grids
   --------------------------------------------------------------------- */
.ghu-steps-grid { display: flex; flex-wrap: wrap; gap: .85rem; }
.ghu-step {
  flex: 1 1 215px; min-width: 200px;
  background: #FFFFFF; border: 1px solid $border;
  border-radius: var(--ghu-radius-sm);
  padding: 1.05rem 1.1rem .95rem 1.1rem;
  box-shadow: var(--ghu-shadow); position: relative;
}
.ghu-step__num {
  display: inline-flex; align-items: center; justify-content: center;
  width: 30px; height: 30px; border-radius: 50%;
  background: $primary; color: #FFFFFF;
  font-family: $font_body; font-size: .88rem; font-weight: 800;
  margin-bottom: .55rem;
}
.ghu-step__title { font-family: $font_body; font-size: .95rem; font-weight: 700; color: $ink; margin: 0 0 .28rem 0; }
.ghu-step__text { font-family: $font_body; font-size: .85rem; line-height: 1.6; color: $muted; margin: 0; }
.ghu-grid3 { display: flex; flex-wrap: wrap; gap: .85rem; }
.ghu-grid3 > * { flex: 1 1 250px; min-width: 220px; }
.ghu-spacer { height: 1.1rem; }
.ghu-spacer--sm { height: .55rem; }

@media (max-width: 780px) {
  .ghu-h1 { font-size: 2rem; }
  .ghu-hero__title { font-size: 1.85rem; }
  .ghu-hero__panel { padding: 1.5rem 1.25rem; }
  .ghu-primary__email { font-size: 1rem; }
  .ghu-barrow__label { flex: 1 1 100%; }
}
"""
)


def css() -> str:
    """Render the stylesheet with the configured palette substituted in."""
    from portal.assets import img_src

    hero = img_src("campus_hero.png")
    values = {**THEME, "font_display": FONT_DISPLAY, "font_body": FONT_BODY}
    values["hero_url"] = hero or "none"
    return _CSS_TEMPLATE.substitute(values)


def inject_css() -> None:
    """Push the design system into the current Streamlit page."""
    import streamlit as st

    st.markdown(f"<style>{css()}</style>", unsafe_allow_html=True)
