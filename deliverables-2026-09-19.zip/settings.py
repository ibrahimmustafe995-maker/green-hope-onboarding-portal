"""Configuration loader.

Reads ``config.yaml`` sitting next to ``app.py`` and exposes it as plain
dictionaries. The portal never hard-codes branding, contacts or colours —
everything flows through here, which is what makes the app re-skinnable.

Design notes
------------
* ``config.yaml`` is deep-merged over ``DEFAULT_CONFIG``, so a partial or
  missing file still yields a fully working portal rather than a crash.
* PyYAML ships as a Streamlit dependency, but we degrade gracefully to the
  built-in defaults if it is somehow unavailable.
"""

from __future__ import annotations

import copy
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict

try:  # PyYAML is a Streamlit dependency; keep a fallback anyway.
    import yaml
except ImportError:  # pragma: no cover - only hit in exotic environments
    yaml = None  # type: ignore[assignment]


# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
APP_DIR: Path = Path(__file__).resolve().parent.parent
CONFIG_PATH: Path = APP_DIR / "config.yaml"
DATA_DIR: Path = APP_DIR / "data"
ASSETS_DIR: Path = APP_DIR / "assets"


# --------------------------------------------------------------------------
# Fallback configuration — mirrors config.yaml, guarantees the app boots.
# --------------------------------------------------------------------------
DEFAULT_CONFIG: Dict[str, Any] = {
    "brand": {
        "university": "Green Hope University",
        "campus": "Garowe Campus",
        "portal_name": "Freshman Orientation & Welcome Portal",
        "short_name": "GHU Garowe",
        "motto": "Knowledge · Service · Hope",
        "established": 1998,
    },
    "contact": {
        "primary_email": "garowecampus@greenhopeuniversity.edu.so",
        "primary_label": "Garowe Campus — Front Desk & General Enquiries",
        "primary_email_alt": "admissions@greenhopeuniversity.edu.so",
        "switchboard": "+252 90 7 000 100",
        "whatsapp": "+252 90 7 000 101",
        "office": "Administration Block A, Ground Floor, Garowe Campus",
        "hours": "Sunday – Thursday · 8:00 AM – 4:00 PM (EAT)",
        "website": "https://www.greenhopeuniversity.edu.so",
        "city": "Garowe, Puntland State, Somalia",
        "map_note": "Approx. 1.2 km east of Garowe Central Roundabout",
    },
    "theme": {
        "primary": "#0E7350",
        "primary_dark": "#0A5238",
        "primary_light": "#E6F2ED",
        "primary_soft": "#CFE6DC",
        "gold": "#C9A227",
        "gold_light": "#FBF3D9",
        "sand": "#F2EBDC",
        "cream": "#FDFBF5",
        "ink": "#14261E",
        "muted": "#5C7069",
        "border": "#DFD8C8",
        "success": "#1B7F5A",
        "warning": "#C97B1E",
        "danger": "#B23A2E",
    },
    "orientation": {
        "academic_year": "2026 / 2027",
        "week_start": "2026-09-21",
        "week_end": "2026-09-25",
        "registration_deadline": "2026-09-30",
        "fees_deadline": "2026-10-05",
        "course_registration_deadline": "2026-10-08",
        "timezone": "EAT (UTC+3)",
    },
    "demo": {
        "student": {
            "name": "Amina Yusuf Abdi",
            "student_id": "GHU-2026-10482",
            "programme": "BSc Computer Science",
            "faculty": "Faculty of Computing & Engineering",
            "residency": "On-campus (Hostel)",
            "email": "amina.yusuf@student.greenhopeuniversity.edu.so",
            "phone": "+252 90 7 123 456",
            "nationality": "Somali",
        },
        "precompletion": ["reg_docs", "email_portal", "tuition", "id_card"],
    },
}


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively merge ``override`` into a copy of ``base``.

    Nested dictionaries are merged key-by-key; anything else (lists, scalars)
    is replaced wholesale by the overriding value. This lets ``config.yaml``
    specify only the keys it wants to change.
    """
    result = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result


def _read_yaml(path: Path) -> Dict[str, Any]:
    """Load a YAML file, returning ``{}`` on any problem."""
    if yaml is None or not path.exists():
        return {}
    try:
        with path.open("r", encoding="utf-8") as handle:
            loaded = yaml.safe_load(handle)
        return loaded if isinstance(loaded, dict) else {}
    except Exception:  # noqa: BLE001 - a bad config must never break the app
        return {}


@lru_cache(maxsize=1)
def get_config() -> Dict[str, Any]:
    """Return the fully-resolved configuration (cached for the process)."""
    return _deep_merge(DEFAULT_CONFIG, _read_yaml(CONFIG_PATH))


def reload_config() -> Dict[str, Any]:
    """Clear the cache and re-read config.yaml (useful while editing)."""
    get_config.cache_clear()
    return get_config()


# --------------------------------------------------------------------------
# Convenience accessors — imported directly by the view modules.
# --------------------------------------------------------------------------
CFG: Dict[str, Any] = get_config()
THEME: Dict[str, str] = CFG["theme"]
BRAND: Dict[str, Any] = CFG["brand"]
CONTACT: Dict[str, Any] = CFG["contact"]
ORIENTATION: Dict[str, Any] = CFG["orientation"]
DEMO: Dict[str, Any] = CFG["demo"]

PRIMARY_EMAIL: str = CONTACT["primary_email"]
PRIMARY_EMAIL_LABEL: str = CONTACT["primary_label"]

UNIVERSITY: str = BRAND["university"]
CAMPUS: str = BRAND["campus"]
PORTAL_NAME: str = BRAND["portal_name"]


def full_title() -> str:
    """Human-readable portal title, e.g. ``Green Hope University — Garowe Campus``."""
    return f"{UNIVERSITY} — {CAMPUS}"
