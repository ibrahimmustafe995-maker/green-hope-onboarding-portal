"""Progress tab — the orientation tracking dashboard.

Answers, at a glance: how far along am I, which parts are lagging, what is
overdue, what should I do next, and what happens during orientation week.

Visual budget
-------------
The completion ring and the phase/category bars are hand-built (SVG + CSS)
so they render correctly even before their tab is opened. Plotly is used
only for the deadline countdown, where hover detail genuinely helps.
"""

from __future__ import annotations

from datetime import date
from typing import List

import streamlit as st

from portal import components as ui
from portal import state
from portal.data import ORIENTATION_SCHEDULE, PHASES, ScheduleEvent
from portal.logic import progress
from portal.settings import ORIENTATION, THEME

__all__ = ["render"]

_TAG_VARIANT = {"Mandatory": "success", "Recommended": "gold", "Social": "grey"}


# ===========================================================================
# Blocks
# ===========================================================================
def _status_card(summary: progress.ProgressSummary) -> str:
    """The big completion ring with its caption and status line."""
    if summary.is_complete:
        headline = "Everything is done — you are ready for classes."
        note = "Welcome to Green Hope University. See you on the first day of teaching."
    elif summary.completed_count == 0:
        headline = "Let's get you started."
        note = "Begin with Phase 1 — registration, fees and your portal account."
    else:
        headline = f"{len(summary.pending_items)} steps to go."
        next_title = summary.next_up[0].title if summary.next_up else ""
        note = f"Suggested next: {next_title}" if next_title else ""

    body = (
        ui.donut(summary.percent, caption="complete")
        + f'<p class="ghu-h3" style="text-align:center;margin-top:.5rem;">'
        f"{ui.esc(headline)}</p>"
        + f'<p class="ghu-small" style="text-align:center;margin:0;">'
        f"{ui.esc(note)}</p>"
        + f'<div class="ghu-legend" style="justify-content:center;">'
        f'<span class="ghu-legend__item"><span class="ghu-dot ghu-dot--done"></span>'
        f"{summary.completed_count} complete</span>"
        f'<span class="ghu-legend__item"><span class="ghu-dot ghu-dot--todo"></span>'
        f"{len(summary.pending_items)} remaining</span>"
        f"</div>"
    )
    return ui.card(body)


def _next_up_card(summary: progress.ProgressSummary) -> str:
    """The three highest-priority outstanding steps."""
    if not summary.next_up:
        return ui.card(
            f'<p class="ghu-h3">Nothing outstanding 🎉</p>'
            f'<p class="ghu-small" style="margin:0;">'
            f"Every onboarding step is complete. Keep an eye on your student "
            f"email for teaching updates.</p>",
            variant="light",
        )

    rows = ""
    for item in summary.next_up:
        info = progress.deadline_info(item)
        if info.days_left is None:
            when = item.deadline_label
        elif info.overdue:
            when = f"Overdue by {abs(info.days_left)} day{'s' if abs(info.days_left) != 1 else ''}"
        elif info.days_left == 0:
            when = "Due today"
        else:
            when = f"Due in {info.days_left} day{'s' if info.days_left != 1 else ''}"

        rows += (
            f'<div class="ghu-dl__row">'
            f'<div class="ghu-dl__k" style="flex:0 0 30%;">{ui.esc(item.category)}</div>'
            f'<div class="ghu-dl__v"><span class="ghu-strong">{ui.esc(item.title)}</span>'
            f'<br/><span class="ghu-small">{ui.esc(when)}</span></div>'
            f"</div>"
        )

    return ui.card(
        f'<p class="ghu-eyebrow">Do these next</p>'
        f'<p class="ghu-h3" style="margin-bottom:.35rem;">Your next three steps</p>'
        f'<div class="ghu-dl">{rows}</div>',
        variant="light",
    )


def _phase_bars(summary: progress.ProgressSummary) -> str:
    """Weighted completion for each orientation phase."""
    rows = [
        {
            "label": stat.name.split(" · ", 1)[-1],
            "percent": stat.percent,
            "value_text": f"{stat.completed_count}/{stat.total_count}",
            "variant": "gold" if stat.is_complete else "",
        }
        for stat in summary.phases
    ]
    body = (
        f'<p class="ghu-h3">By orientation phase</p>'
        f'<p class="ghu-small" style="margin-bottom:.6rem;">'
        f"Bar length is weighted completion; the figure is steps done.</p>"
        + ui.bar_rows(rows)
    )
    return ui.card(body)


def _category_bars(summary: progress.ProgressSummary) -> str:
    """Completion split by category — shows where the work concentrates."""
    rows = [
        {
            "label": stat.name,
            "percent": stat.percent,
            "value_text": f"{stat.completed_count}/{stat.total_count}",
            "variant": "gold" if stat.is_complete else "",
        }
        for stat in summary.categories
    ]
    body = (
        f'<p class="ghu-h3">By category</p>'
        f'<p class="ghu-small" style="margin-bottom:.6rem;">'
        f"Ordered by weight, so the heaviest obligations sit at the top.</p>"
        + ui.bar_rows(rows)
    )
    return ui.card(body)


def _deadline_chart(summary: progress.ProgressSummary, today: date) -> None:
    """Plotly horizontal bar: days remaining on each outstanding deadline.

    Plotly is used only here, where hover values add real information; the
    ring and bars above are SVG/CSS so they never depend on canvas layout.
    """
    rows = []
    for item in summary.pending_items:
        due = progress.parse_iso(item.deadline)
        if due is None:
            continue
        rows.append((item.title, (due - today).days))

    if not rows:
        st.markdown(
            ui.empty(
                "No dated deadlines outstanding — the remaining steps are not time-boxed."
            ),
            unsafe_allow_html=True,
        )
        return

    rows.sort(key=lambda r: r[1])
    labels = [r[0] for r in rows]
    days = [r[1] for r in rows]
    colours = [
        THEME["danger"] if d < 0 else (THEME["warning"] if d <= 7 else THEME["primary"])
        for d in days
    ]

    import plotly.graph_objects as go

    fig = go.Figure(
        go.Bar(
            x=days,
            y=labels,
            orientation="h",
            marker=dict(color=colours, line=dict(width=0)),
            text=[f"{d} d" for d in days],
            textposition="outside",
            cliponaxis=False,
            hovertemplate="%{y}<br>%{x} days remaining<extra></extra>",
        )
    )
    fig.update_layout(
        height=max(240, 44 * len(rows) + 80),
        margin=dict(l=8, r=34, t=8, b=34),
        showlegend=False,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="system-ui, -apple-system, Segoe UI, Roboto, sans-serif",
                  size=12, color=THEME["ink"]),
        xaxis=dict(title="Days remaining", zeroline=True,
                   zerolinecolor=THEME["border"], gridcolor="#EFEADC"),
        yaxis=dict(automargin=True),
        bargap=0.38,
    )
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})


def _timeline() -> str:
    """The orientation week schedule as a vertical timeline."""
    events = ""
    for ev in ORIENTATION_SCHEDULE:
        cls = f"ghu-ev ghu-ev--{ev.tag.lower()}"
        events += (
            f'<div class="{cls}">'
            f'<p class="ghu-ev__when">{ui.esc(ev.day_label)} · {ui.esc(ev.time)}</p>'
            f'<p class="ghu-ev__title">{ui.esc(ev.title)}</p>'
            f'<p class="ghu-ev__detail">{ui.esc(ev.detail)}</p>'
            f'<p class="ghu-ev__venue">📍 {ui.esc(ev.venue)} · {ui.esc(ev.tag)}</p>'
            f"</div>"
        )
    return (
        f'<p class="ghu-eyebrow">Orientation week · {ui.esc(ORIENTATION["week_start"])} '
        f'to {ui.esc(ORIENTATION["week_end"])}</p>'
        f'<p class="ghu-h2" style="font-size:1.35rem;">What happens, day by day</p>'
        f'<p class="ghu-small" style="margin-bottom:.9rem;">'
        f'All times are {ui.esc(ORIENTATION["timezone"])}. '
        f'Sessions marked Mandatory are recorded on your file.</p>'
        f'<div class="ghu-timeline">{events}</div>'
    )


def _remaining_table(summary: progress.ProgressSummary, today: date) -> None:
    """A compact table of outstanding steps, with owner and deadline state."""
    import pandas as pd

    from portal.data import department_by_slug

    if not summary.pending_items:
        st.markdown(ui.empty("Nothing outstanding."), unsafe_allow_html=True)
        return

    records: List[dict] = []
    for item in summary.pending_items:
        info = progress.deadline_info(item, today)
        dept = department_by_slug(item.dept)
        if info.days_left is None:
            state_label = "No fixed deadline"
        elif info.overdue:
            state_label = f"Overdue ({abs(info.days_left)} d)"
        elif info.days_left == 0:
            state_label = "Due today"
        else:
            state_label = f"{info.days_left} days left"
        records.append(
            {
                "Step": item.title,
                "Phase": item.phase.split(" · ", 1)[-1],
                "Category": item.category,
                "Responsible office": dept.name if dept else "—",
                "Deadline": item.deadline_label,
                "Status": state_label,
                "Points": item.weight,
            }
        )

    frame = pd.DataFrame(records).sort_values(["Points"], ascending=False)
    st.dataframe(
        frame,
        hide_index=True,
        use_container_width=True,
        column_config={
            "Points": st.column_config.NumberColumn(
                "Weight", help="Contribution to the overall completion percentage", width="small"
            ),
        },
    )


# ===========================================================================
# Tab entry point
# ===========================================================================
def render() -> None:
    """Draw the Progress tab."""
    done = state.completed_ids()
    today = progress.as_date(None)
    summary = progress.summarize(done, today)

    st.markdown(
        f'<div class="ghu-section">{ui.section_head("Your orientation progress", "A live view of where you stand and what is left to do.", "Tracking")}</div>',
        unsafe_allow_html=True,
    )

    # --- Top KPI strip ------------------------------------------------------
    st.markdown(
        ui.kpi_row(
            [
                {"label": "Overall", "value": f"{summary.percent:.0f}%",
                 "note": f"{summary.completed_weight}/{summary.total_weight} points"},
                {"label": "Steps complete", "value": f"{summary.completed_count}/{summary.total_count}",
                 "note": summary.status},
                {"label": "Remaining", "value": str(len(summary.pending_items)),
                 "note": f"{summary.remaining_weight} points of work"},
                {"label": "Overdue", "value": str(len(summary.overdue_items)),
                 "note": "past deadline",
                 "variant": "warning" if summary.overdue_items else ""},
            ]
        ),
        unsafe_allow_html=True,
    )
    st.markdown(ui.spacer(), unsafe_allow_html=True)

    # --- Ring + next steps --------------------------------------------------
    left, right = st.columns([1, 1.25], gap="medium")
    with left:
        st.markdown(_status_card(summary), unsafe_allow_html=True)
    with right:
        st.markdown(_next_up_card(summary), unsafe_allow_html=True)
        if summary.overdue_items:
            overdue_names = ", ".join(i.title for i in summary.overdue_items)
            st.markdown(
                f'<div class="ghu-note" style="margin-top:.2rem;">'
                f"⚠️ <b>Overdue:</b> {ui.esc(overdue_names)}. Contact the relevant "
                f"office as soon as possible — most deadlines can still be "
                f"accommodated if you speak to them early."
                f"</div>",
                unsafe_allow_html=True,
            )

    # --- Breakdowns ---------------------------------------------------------
    st.markdown(
        f'<div class="ghu-section">{ui.section_head("Completion breakdown", "How the work is distributed, and where you stand in each part.")}</div>',
        unsafe_allow_html=True,
    )
    col_a, col_b = st.columns(2, gap="medium")
    with col_a:
        st.markdown(_phase_bars(summary), unsafe_allow_html=True)
    with col_b:
        st.markdown(_category_bars(summary), unsafe_allow_html=True)

    # --- Deadline countdown -------------------------------------------------
    st.markdown(
        f'<div class="ghu-section">{ui.section_head("Deadline countdown", "Days remaining on each outstanding step that has a fixed deadline.")}</div>',
        unsafe_allow_html=True,
    )
    _deadline_chart(summary, today)

    # --- Timeline -----------------------------------------------------------
    st.markdown('<div class="ghu-section"></div>', unsafe_allow_html=True)
    st.markdown(_timeline(), unsafe_allow_html=True)

    # --- What is left -------------------------------------------------------
    st.markdown(
        f'<div class="ghu-section">{ui.section_head("What is left, in detail", "Every outstanding step, its owner and its deadline status.")}</div>',
        unsafe_allow_html=True,
    )
    _remaining_table(summary, today)

    if summary.is_complete:
        st.success(
            "All ten onboarding steps are complete. You are fully enrolled and "
            "ready for teaching — well done."
        )
