"""Build one-click ``mailto:`` links with pre-filled subject and body.

Kept deliberately free of Streamlit imports so it can be unit-tested and
reused (e.g. from a CLI mailer) without a running app.

Encoding notes
--------------
``urllib.parse.urlencode`` defaults to ``quote_plus``, which turns spaces
into ``+``. Mail clients vary in how they read that in a ``mailto:`` body,
so we pass ``quote_via=quote`` to percent-encode instead — newlines become
``%0A`` and spaces ``%20``, which every mainstream client handles.
"""

from __future__ import annotations

from typing import Any, Dict, Mapping
from urllib.parse import quote, urlencode

from portal.data import EnquiryTemplate
from portal.settings import CONTACT, PRIMARY_EMAIL

__all__ = [
    "PLACEHOLDERS",
    "DEFAULT_STUDENT",
    "build_mailto",
    "render_template",
    "template_context",
    "template_mailto",
    "quick_mailto",
    "mailto_attrs",
]


class _SafeDict(dict):
    """``format_map`` helper that leaves unknown ``{placeholders}`` intact.

    A student template containing a token we do not know about should render
    literally rather than raise ``KeyError`` and crash the page.
    """

    def __missing__(self, key: str) -> str:  # noqa: D105
        return "{" + key + "}"


# Placeholders available inside an enquiry template's subject/body.
PLACEHOLDERS: tuple[str, ...] = (
    "name",
    "student_id",
    "programme",
    "faculty",
    "email",
    "phone",
    "academic_year",
    "campus_email",
)

# Used when the visitor has not entered a profile yet.
DEFAULT_STUDENT: Dict[str, str] = {
    "name": "New Freshman",
    "student_id": "(to be issued)",
    "programme": "(not yet selected)",
    "faculty": "",
    "email": "",
    "phone": "",
}


def _escape_ampersands(value: str) -> str:
    """Make a value safe to sit inside a ``mailto:`` query.

    ``urlencode`` encodes most characters, but a bare ``&`` that slips
    through would terminate the parameter early and corrupt the body.
    """
    return (value or "").replace("&", "%26").replace("?", "%3F")


def build_mailto(to: str, subject: str = "", body: str = "") -> str:
    """Compose a ``mailto:`` URL with optional pre-filled subject and body.

    >>> build_mailto("a@b.so", "Hi", "Line 1\\nLine 2")[:24]
    'mailto:a@b.so?subject=Hi'
    """
    address = (to or "").strip() or PRIMARY_EMAIL
    params: Dict[str, str] = {}
    if subject:
        params["subject"] = _escape_ampersands(subject)
    if body:
        params["body"] = _escape_ampersands(body)

    if not params:
        return f"mailto:{address}"
    return f"mailto:{address}?{urlencode(params, quote_via=quote)}"


def template_context(student: Mapping[str, Any] | None = None) -> Dict[str, str]:
    """Merge a student profile over the defaults, adding campus constants."""
    context: Dict[str, str] = dict(DEFAULT_STUDENT)
    if student:
        for key, value in student.items():
            if isinstance(key, str) and value is not None:
                context[key] = str(value)
    context["campus_email"] = PRIMARY_EMAIL
    return context


def render_template(text: str, student: Mapping[str, Any] | None = None) -> str:
    """Fill ``{placeholders}`` in a template string from the student profile."""
    if not text:
        return ""
    return text.format_map(_SafeDict(template_context(student)))


def template_mailto(
    template: EnquiryTemplate,
    student: Mapping[str, Any] | None = None,
    to: str | None = None,
) -> str:
    """Build the ready-to-send ``mailto:`` URL for one enquiry template.

    ``to`` overrides the template's home department — useful for routing an
    enquiry to the campus-wide address instead.
    """
    subject = render_template(template.subject, student)
    body = render_template(template.body, student)
    return build_mailto(to or _department_email(template.dept), subject, body)


def quick_mailto(
    subject: str,
    body: str,
    to: str | None = None,
    student: Mapping[str, Any] | None = None,
) -> str:
    """Convenience wrapper for an ad-hoc pre-filled message."""
    return build_mailto(
        to or PRIMARY_EMAIL,
        render_template(subject, student),
        render_template(body, student),
    )


def _department_email(slug: str) -> str:
    """Resolve a department slug to its email, falling back to the campus one."""
    # Imported lazily to keep this module import-cheap and cycle-free.
    from portal.data import department_by_slug

    dept = department_by_slug(slug)
    return dept.email if dept else PRIMARY_EMAIL


def mailto_attrs(url: str) -> str:
    """Attributes for an ``<a>`` that opens the mail client.

    ``target="_blank"`` with ``rel`` prevents the Streamlit frame from being
    navigated away from, which would blank the app.
    """
    safe = (url or "").replace('"', "%22")
    return f'href="{safe}" target="_blank" rel="noopener noreferrer"'
