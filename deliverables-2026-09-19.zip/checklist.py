"""Onboarding Checklist tab — the interactive core of the portal.

Ten steps, grouped into the three orientation phases. Each row is a real
checkbox whose state is mirrored into session state *and* persisted to disk,
so a student can close the tab and come back tomorrow.

Every row also carries its own guidance — why it matters, the exact steps,
what to bring, the fee, where to go, and a tip — inside an expander, so the
list stays scannable while the detail is one click away.
"""

from __future__ import annotations

from typing import List

import streamlit as st

from portal import components as ui
from portal import state
from portal.data import PHASE_BLURBS, PHASES, ChecklistItem, department_by_slug
from portal.logic import mailto, progress
from portal.settings import CONTACT

__all__ = ["render"]


# ===========================================================================
# Widget callbacks
# ===========================================================================
def _on_toggle(item_id: str) -> None:
    """Persist a checkbox change the moment it happens.

    ``sync_widget=False`` because Streamlit forbids writing a widget's own
    key from inside its callback — the widget already holds the new value.
    """
    new_value = bool(st.session_state.get(f"chk_{item_id}", False))
    state.set_done(item_id, new_value, persist_now=True, sync_widget=False)


# ===========================================================================
# Row rendering
# ===========================================================================
def _deadline_chip(item: ChecklistItem) -> str:
    """A colour-coded chip describing the item's deadline state."""
    info = progress.deadline_info(item)
    if info.state == "none" or info.days_left is None:
        return ui.chip(item.deadline_label, "grey")
    if info.state == "overdue":
        return ui.chip(f"Overdue · {item.deadline_label}", "danger")
    if info.state == "due-soon":
        days = info.days_left
        return ui.chip(f"Due in {days} day{'s' if days != 1 else ''}", "warning")
    return ui.chip(f"Due {item.deadline_label}", "plain")


def _guidance(item: ChecklistItem, student: dict) -> None:
    """Everything a student needs to actually complete one step."""
    dept = department_by_slug(item.dept)

    # --- Why it matters -----------------------------------------------------
    st.markdown(
        f'<p class="ghu-small" style="margin:0 0 .5rem 0;">{ui.esc(item.summary)}</p>',
        unsafe_allow_html=True,
    )

    # --- Ordered steps ------------------------------------------------------
    steps = "".join(f"<li>{ui.esc(s)}</li>" for s in item.steps)
    st.markdown(
        f'<p class="ghu-kpi__label" style="margin-bottom:.2rem;">What to do</p>'
        f'<ol class="ghu-steps">{steps}</ol>',
        unsafe_allow_html=True,
    )

    # --- Practical detail ---------------------------------------------------
    rows: List[str] = []
    if item.documents:
        docs = ", ".join(item.documents)
        rows.append(("What to bring", docs))
    rows.append(("Fee", item.fee))
    if item.location:
        rows.append(("Where", item.location))
    if dept:
        rows.append(("Office", f"{dept.name} · {dept.contact_person}, {dept.contact_role}"))

    detail = "".join(
        f'<div class="ghu-dl__row"><div class="ghu-dl__k">{ui.esc(k)}</div>'
        f'<div class="ghu-dl__v">{ui.esc(v)}</div></div>'
        for k, v in rows
    )
    st.markdown(f'<div class="ghu-dl">{detail}</div>', unsafe_allow_html=True)

    # --- Tip ----------------------------------------------------------------
    if item.tip:
        st.markdown(f'<div class="ghu-note">{ui.esc(item.tip)}</div>', unsafe_allow_html=True)

    # --- One-click email to the owning office -------------------------------
    if dept:
        student_ctx = dict(student)
        student_ctx.setdefault("programme", "")
        subject = f"Question about: {item.title} — {student_ctx.get('name') or 'New freshman'}"
        body = (
            f"Dear {dept.name},\n\n"
            f"I am a new freshman and I have a question about the following "
            f"onboarding step:\n\n"
            f"  {item.title}\n\n"
            f"My question:\n\n\n\n"
            f"My details:\n"
            f"Full name: {student_ctx.get('name') or ''}\n"
            f"Student / application ID: {student_ctx.get('student_id') or ''}\n"
            f"Programme: {student_ctx.get('programme') or ''}\n"
            f"Phone: {student_ctx.get('phone') or ''}\n\n"
            f"Thank you for your help.\n\n"
            f"Kind regards,\n{student_ctx.get('name') or ''}"
        )
        url = mailto.build_mailto(dept.email, subject, body)
        st.markdown(
            ui.button_row(
                [
                    {"label": f"Email {dept.name}", "href": url, "variant": "primary"},
                    {
                        "label": f"Call {dept.phone}",
                        "href": f"tel:{dept.phone.replace(' ', '')}",
                        "variant": "ghost",
                    },
                ]
            ),
            unsafe_allow_html=True,
        )


def _render_item(item: ChecklistItem, student: dict) -> None:
    """One checklist row: checkbox, meta chips, expander with guidance."""
    with st.container(border=True):
        st.checkbox(
            item.title,
            key=f"chk_{item.id}",
            on_change=_on_toggle,
            args=(item.id,),
            help=item.summary,
        )

        meta = (
            ui.chip(item.category, "plain")
            + ui.chip(f"{item.weight} of 100 points", "grey")
            + _deadline_chip(item)
        )
        st.markdown(f'<div class="ghu-check__meta">{meta}</div>', unsafe_allow_html=True)
        st.markdown(
            f'<p class="ghu-check__summary">{ui.esc(item.summary)}</p>',
            unsafe_allow_html=True,
        )

        with st.expander("Guidance, documents, fee & contact"):
            _guidance(item, student)


# ===========================================================================
# Tab entry point
# ===========================================================================
def render() -> None:
    """Draw the Onboarding Checklist tab."""
    done = state.completed_ids()
    summary = progress.summarize(done)
    student = state.get_student()

    # --- Header -------------------------------------------------------------
    st.markdown(
        f'<div class="ghu-section">{ui.section_head("Your freshman onboarding checklist", "Ten steps. Tick each one as you complete it — your progress saves automatically.", "Onboarding")}</div>',
        unsafe_allow_html=True,
    )

    # --- Live progress strip ------------------------------------------------
    st.markdown(
        ui.kpi_row(
            [
                {"label": "Complete", "value": f"{summary.percent:.0f}%",
                 "note": f"{summary.completed_weight} of {summary.total_weight} points"},
                {"label": "Steps done", "value": f"{summary.completed_count}/{summary.total_count}",
                 "note": summary.status},
                {"label": "Still to do", "value": str(len(summary.pending_items)),
                 "note": "across three phases"},
                {"label": "Overdue", "value": str(len(summary.overdue_items)),
                 "note": "past their deadline",
                 "variant": "warning" if summary.overdue_items else ""},
            ]
        ),
        unsafe_allow_html=True,
    )

    # --- Overall bar + view controls ---------------------------------------
    st.markdown(
        ui.bar_row("Overall completion", summary.percent, f"{summary.percent:.0f}%"),
        unsafe_allow_html=True,
    )

    st.markdown(ui.spacer(small=True), unsafe_allow_html=True)
    ctrl_left, ctrl_mid, ctrl_right = st.columns([1.15, 1, 1.6])
    with ctrl_left:
        hide_done = st.toggle("Hide completed steps", value=False, key="hide_done")
    with ctrl_mid:
        if st.button("Save now", use_container_width=True, key="save_now"):
            state.save_now()
            st.toast("Progress saved.", icon="✅")
    with ctrl_right:
        saved = state.persisted_at()
        stamp = saved.replace("T", " ").replace("+00:00", " UTC") if saved else "not yet saved"
        st.markdown(
            f'<p class="ghu-small" style="text-align:right;padding-top:.55rem;margin:0;">'
            f"Auto-saved · last save: {ui.esc(stamp)}</p>",
            unsafe_allow_html=True,
        )

    # --- Phase sections -----------------------------------------------------
    any_rendered = False
    for phase in PHASES:
        items = [i for i in _items_in(phase) if not (hide_done and i.id in done)]
        stat = next((s for s in summary.phases if s.name == phase), None)

        st.markdown(
            f'<div class="ghu-section">{ui.section_head(phase, PHASE_BLURBS.get(phase, ""))}</div>',
            unsafe_allow_html=True,
        )
        if stat:
            st.markdown(
                ui.bar_row(
                    f"{stat.completed_count} of {stat.total_count} steps",
                    stat.percent,
                    f"{stat.percent:.0f}%",
                    variant="gold" if stat.is_complete else "",
                ),
                unsafe_allow_html=True,
            )
        st.markdown(ui.spacer(small=True), unsafe_allow_html=True)

        if not items:
            st.markdown(
                ui.empty("Every step in this phase is complete — nicely done."),
                unsafe_allow_html=True,
            )
            continue

        for item in items:
            _render_item(item, student)
            any_rendered = True

    if not any_rendered:
        st.markdown(
            ui.empty("Nothing left to show — all ten steps are complete. 🎉"),
            unsafe_allow_html=True,
        )
        st.balloons()

    # --- Contact fallback ---------------------------------------------------
    st.markdown(
        f'<div class="ghu-foot">'
        f"Need help with any step? Write to the campus front desk at "
        f'<span class="ghu-mono">{ui.esc(CONTACT["primary_email"])}</span> '
        f"or call {ui.esc(CONTACT['switchboard'])}."
        f"</div>",
        unsafe_allow_html=True,
    )


def _items_in(phase: str) -> List[ChecklistItem]:
    """All checklist items belonging to one phase, in declaration order."""
    from portal.data import CHECKLIST_ITEMS

    return [item for item in CHECKLIST_ITEMS if item.phase == phase]
