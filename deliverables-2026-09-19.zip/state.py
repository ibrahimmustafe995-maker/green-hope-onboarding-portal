"""Progress persistence, backed by ``st.session_state`` plus a JSON file.

Session state alone is lost the moment the browser tab is closed, which for
an onboarding checklist is the wrong behaviour — a student should be able to
come back tomorrow and find their ticks still there. So every change is
mirrored to ``state/progress.json`` and replayed on start-up.

Swapping this for a real backend later means reimplementing only
``load_persisted`` / ``save_persisted``; nothing else in the app touches the
storage layer directly.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Set

import streamlit as st

from portal.data import CHECKLIST_ITEMS
from portal.settings import APP_DIR, DEMO

__all__ = [
    "STATE_DIR",
    "PROGRESS_FILE",
    "init_state",
    "is_done",
    "set_done",
    "completed_ids",
    "set_completed",
    "reset_progress",
    "sync_checkbox_keys",
    "get_student",
    "update_student",
    "demo_student_id",
    "load_demo_student",
    "persisted_at",
    "save_now",
]

STATE_DIR: Path = APP_DIR / "state"
PROGRESS_FILE: Path = STATE_DIR / "progress.json"

_SCHEMA_VERSION = 1

# Session-state keys, namespaced so they cannot collide with widget keys.
_K_COMPLETED = "ghu_completed"
_K_STUDENT = "ghu_student"
_K_LOADED = "ghu_loaded_from_disk"
_K_SAVED_AT = "ghu_saved_at"

# One-shot status message shown on the rerun a programmatic action triggers.
FLASH_KEY = "ghu_flash"

_VALID_IDS: Set[str] = {item.id for item in CHECKLIST_ITEMS}

_EMPTY_STUDENT: Dict[str, str] = {
    "name": "",
    "student_id": "",
    "programme": "",
    "faculty": "",
    "residency": "",
    "email": "",
    "phone": "",
    "nationality": "",
}


# ===========================================================================
# Disk layer
# ===========================================================================
def load_persisted() -> Dict[str, Any]:
    """Read ``state/progress.json``; return an empty shell on any problem."""
    if not PROGRESS_FILE.is_file():
        return {}
    try:
        with PROGRESS_FILE.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        # A corrupt or unreadable file must never stop the portal booting —
        # the student simply starts from a clean checklist.
        return {}


def save_persisted(payload: Dict[str, Any]) -> bool:
    """Write the progress payload atomically. Returns success."""
    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        temp = PROGRESS_FILE.with_suffix(".json.tmp")
        with temp.open("w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, ensure_ascii=False)
        temp.replace(PROGRESS_FILE)  # atomic on POSIX — no half-written file
        return True
    except OSError:
        return False


# ===========================================================================
# Session-state layer
# ===========================================================================
def init_state() -> None:
    """Seed session state on first run of a browser session."""
    if st.session_state.get(_K_LOADED):
        return

    persisted = load_persisted()

    stored = persisted.get("completed") or []
    restored = {str(x) for x in stored if str(x) in _VALID_IDS}
    st.session_state[_K_COMPLETED] = restored

    student = persisted.get("student")
    if isinstance(student, dict):
        merged = dict(_EMPTY_STUDENT)
        merged.update({k: str(v) for k, v in student.items() if k in merged})
        st.session_state[_K_STUDENT] = merged
    else:
        st.session_state[_K_STUDENT] = dict(_EMPTY_STUDENT)

    st.session_state[_K_SAVED_AT] = persisted.get("saved_at")
    st.session_state[_K_LOADED] = True

    # Push the restored values into the WIDGET keys, before any widget is
    # instantiated (init_state runs first, from _bootstrap). Without this a
    # new session creates each checkbox with its own default of False and
    # silently discards the restored tick — progress.json would exist on
    # disk while the UI still came up blank.
    sync_widget_keys()


def completed_ids() -> Set[str]:
    """Current set of completed checklist-item ids."""
    init_state()
    return set(st.session_state.get(_K_COMPLETED, set()))


def is_done(item_id: str) -> bool:
    """True when the given checklist item is ticked."""
    return item_id in completed_ids()


def persist() -> None:
    """Mirror the current session state to disk."""
    payload = {
        "schema_version": _SCHEMA_VERSION,
        "saved_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "completed": sorted(completed_ids()),
        "student": dict(st.session_state.get(_K_STUDENT, _EMPTY_STUDENT)),
    }
    if save_persisted(payload):
        st.session_state[_K_SAVED_AT] = payload["saved_at"]


def set_done(
    item_id: str,
    done: bool,
    persist_now: bool = True,
    sync_widget: bool = True,
) -> None:
    """Tick or untick an item, keeping the checkbox widget in step."""
    if item_id not in _VALID_IDS:
        return

    current = completed_ids()
    if done:
        current.add(item_id)
    else:
        current.discard(item_id)
    st.session_state[_K_COMPLETED] = current

    # Keep the rendered widget consistent with programmatic changes
    # (reset / demo load) so the UI never contradicts the stored state.
    # Skipped when called FROM a widget callback: Streamlit forbids writing a
    # widget's own key once it has been instantiated in the current run.
    if sync_widget:
        st.session_state[f"chk_{item_id}"] = bool(done)

    if persist_now:
        persist()


def set_completed(ids: List[str] | Set[str], persist_now: bool = True) -> None:
    """Replace the whole completion set (used by reset and demo loading)."""
    clean = {str(i) for i in ids if str(i) in _VALID_IDS}
    st.session_state[_K_COMPLETED] = clean
    sync_checkbox_keys()
    if persist_now:
        persist()


def reset_progress(persist_now: bool = True) -> None:
    """Clear every tick — a full fresh start.

    Safe to call from a widget callback: it runs before the script body, so
    refreshing the widget keys here does not violate Streamlit's rule about
    writing a widget's own key after instantiation.
    """
    set_completed(set(), persist_now=persist_now)
    st.session_state[_K_STUDENT] = dict(_EMPTY_STUDENT)
    sync_widget_keys()
    st.session_state[FLASH_KEY] = "Checklist reset — starting from a clean slate."


def sync_checkbox_keys() -> None:
    """Force every ``chk_*`` widget key to match the stored completion set.

    Widget keys survive a rerun, so after programmatic changes we must
    overwrite them; otherwise Streamlit would keep rendering the stale tick.
    """
    done = completed_ids()
    for item in CHECKLIST_ITEMS:
        st.session_state[f"chk_{item.id}"] = item.id in done


def sync_widget_keys() -> None:
    """Point every widget key at the stored state.

    Called from :func:`init_state` (before any widget exists) and from the
    programmatic actions, so the rendered widgets always agree with what is
    stored. Both halves matter: the checkbox keys drive the checklist, and
    the ``pf_*`` keys drive the sidebar profile inputs.
    """
    done = completed_ids()
    for item in CHECKLIST_ITEMS:
        st.session_state[f"chk_{item.id}"] = item.id in done

    profile = get_student()
    st.session_state["pf_name"] = profile.get("name", "")
    st.session_state["pf_sid"] = profile.get("student_id", "")
    st.session_state["pf_prog"] = profile.get("programme", "")


def save_now() -> None:
    """Public alias used by the sidebar's explicit Save button."""
    persist()


def persisted_at() -> str | None:
    """ISO timestamp of the last successful save, or ``None``."""
    init_state()
    return st.session_state.get(_K_SAVED_AT)


# ===========================================================================
# Student profile
# ===========================================================================
def get_student() -> Dict[str, str]:
    """Current (possibly blank) student profile."""
    init_state()
    return dict(st.session_state.get(_K_STUDENT, _EMPTY_STUDENT))


def update_student(**fields: Any) -> None:
    """Update profile fields and persist."""
    profile = get_student()
    for key, value in fields.items():
        if key in profile:
            profile[key] = "" if value is None else str(value)
    st.session_state[_K_STUDENT] = profile
    persist()


def demo_student_id() -> str:
    """The student id used by the demo profile (for the sidebar badge)."""
    return str(DEMO.get("student", {}).get("student_id", ""))


def load_demo_student() -> None:
    """Populate the demo student and their partially-complete checklist.

    Ids listed under ``demo.precompletion`` in ``config.yaml`` are treated as
    already done — handy for screenshots and live demos, where an empty
    dashboard wastes the first minute of the conversation.
    """
    profile = dict(_EMPTY_STUDENT)
    profile.update({k: str(v) for k, v in DEMO.get("student", {}).items() if k in profile})
    st.session_state[_K_STUDENT] = profile

    # Refresh the pf_* widget keys so the sidebar inputs show the demo
    # student on this very rerun, rather than staying blank.
    sync_widget_keys()
    pre_done = {str(i) for i in DEMO.get("precompletion", []) if str(i) in _VALID_IDS}
    set_completed(pre_done, persist_now=False)
    persist()
    st.session_state[FLASH_KEY] = "Demo student loaded — 43% complete."
