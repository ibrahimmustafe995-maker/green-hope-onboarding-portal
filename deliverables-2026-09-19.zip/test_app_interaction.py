"""Decisive interactivity test using Streamlit's own AppTest harness.

This drives the real app script and interacts with its widgets in-process,
which cleanly separates two possibilities that look identical in a browser:

  * the app's checkbox/callback/persistence wiring is broken, or
  * the browser automation simply failed to land a click on the node.

Run:  python3 /tmp/test_app_interaction.py
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

APP_DIR = Path("/workspace/documents/green-hope-orientation-portal")
os.chdir(APP_DIR)
sys.path.insert(0, str(APP_DIR))

from streamlit.testing.v1 import AppTest  # noqa: E402

PROGRESS_FILE = APP_DIR / "state" / "progress.json"


def fresh() -> None:
    if PROGRESS_FILE.is_file():
        PROGRESS_FILE.unlink()


def main() -> int:
    failures: list[str] = []

    def check(label: str, ok: bool, detail: str = "") -> None:
        print(f"  {'PASS' if ok else 'FAIL'}  {label}" + (f"  → {detail}" if detail and not ok else ""))
        if not ok:
            failures.append(label)

    print("\n=== AppTest: interactivity + persistence ===\n")

    # ---- 1. Cold start with no saved state -------------------------------
    fresh()
    at = AppTest.from_file(str(APP_DIR / "app.py"), default_timeout=60).run()
    check("app runs with no exceptions", not at.exception, str(at.exception))
    check("10 checkboxes rendered", len(at.checkbox) == 10, f"got {len(at.checkbox)}")
    check("4 tabs present", len(at.tabs) == 4, f"got {len(at.tabs)}")
    check("all checkboxes start unchecked", not any(cb.value for cb in at.checkbox))

    # ---- 2. Tick the first checkbox --------------------------------------
    at.checkbox[0].check().run()
    check("no exception after ticking", not at.exception, str(at.exception))
    check("checkbox[0] is now True", at.checkbox[0].value is True,
          f"value={at.checkbox[0].value}")

    # The app must have written the progress file on this interaction.
    check("state/progress.json was created", PROGRESS_FILE.is_file())

    saved: dict = {}
    if PROGRESS_FILE.is_file():
        try:
            saved = json.loads(PROGRESS_FILE.read_text())
        except json.JSONDecodeError as exc:
            check("progress.json is valid JSON", False, str(exc))
    check("saved payload records the ticked item",
          "reg_docs" in (saved.get("completed") or []),
          str(saved.get("completed")))
    check("saved payload has a timestamp", bool(saved.get("saved_at")))

    # ---- 3. Progress arithmetic reflected in the UI ----------------------
    # reg_docs weighs 12, so the overall figure must read 12%.
    body = " ".join(
        [md.value for md in at.markdown]
        + [str(m.value) for m in at.metric]
    )
    check("UI shows 12% after ticking the 12-point item",
          "12%" in body, "12% not found in rendered markdown")
    check("UI shows 1 of 10 steps done", ("1" in body and "10" in body))

    # ---- 4. Persistence across a brand-new session -----------------------
    at2 = AppTest.from_file(str(APP_DIR / "app.py"), default_timeout=60).run()
    check("fresh session restores the ticked item",
          at2.checkbox[0].value is True,
          f"value={at2.checkbox[0].value}")
    check("restored session shows the same count",
          sum(1 for cb in at2.checkbox if cb.value) == 1)

    # ---- 5. Untick it again ----------------------------------------------
    at2.checkbox[0].uncheck().run()
    check("no exception after unticking", not at2.exception, str(at2.exception))
    check("checkbox is False again", at2.checkbox[0].value is False)

    # ---- 6. Demo student button ------------------------------------------
    fresh()
    at3 = AppTest.from_file(str(APP_DIR / "app.py"), default_timeout=60).run()
    demo_btns = [b for b in at3.button if "demo" in str(getattr(b, "label", "")).lower()]
    check("'Load demo student' button exists", len(demo_btns) == 1,
          str([getattr(b, "label", "?") for b in at3.button]))
    if demo_btns:
        demo_btns[0].click().run()
        check("no exception after loading the demo student", not at3.exception,
              str(at3.exception))
        demo_saved = json.loads(PROGRESS_FILE.read_text()) if PROGRESS_FILE.is_file() else {}
        check("demo pre-completes exactly 4 items",
              len(demo_saved.get("completed") or []) == 4,
              str(demo_saved.get("completed")))
        check("demo completes the expected items",
              set(demo_saved.get("completed") or [])
              == {"reg_docs", "email_portal", "tuition", "id_card"},
              str(sorted(demo_saved.get("completed") or [])))
        check("demo profile name persisted",
              (demo_saved.get("student") or {}).get("name") == "Amina Yusuf Abdi",
              str((demo_saved.get("student") or {}).get("name")))

    # ---- 7. All four tabs render without error ---------------------------
    for idx, tab in enumerate(at3.tabs):
        check(f"tab {idx} '{tab.label}' label is non-empty", bool(tab.label))

    fresh()
    print("\n" + "=" * 60)
    if failures:
        print(f"{len(failures)} CHECK(S) FAILED: {failures}")
        return 1
    print("All AppTest interactivity checks passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
