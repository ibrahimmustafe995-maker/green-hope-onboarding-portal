#!/usr/bin/env python3
"""Test suite for the GHU Garowe Freshman Orientation Portal.

Runs standalone — no pytest required::

    python3 tests/test_portal.py

The suite is deliberately split so that the pure-logic checks run **without
Streamlit installed**: ``portal.logic.progress`` and ``portal.logic.mailto``
have no Streamlit import, which is exactly why the business logic lives in
that package.

Exit code is 0 when everything passes, 1 otherwise, so it works in CI.
"""

from __future__ import annotations

import re
import sys
from datetime import date
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

# Make the project importable when run from the repo root or from tests/.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


# ---------------------------------------------------------------------------
# Tiny assertion harness (keeps the file dependency-free)
# ---------------------------------------------------------------------------
class Report:
    """Collects pass/fail results and prints a readable summary."""

    def __init__(self) -> None:
        self.passed = 0
        self.failed: list[tuple[str, str]] = []

    def check(self, label: str, condition: bool, detail: str = "") -> None:
        if condition:
            self.passed += 1
            print(f"  \033[32mPASS\033[0m  {label}")
        else:
            self.failed.append((label, detail))
            print(f"  \033[31mFAIL\033[0m  {label}" + (f"  → {detail}" if detail else ""))

    def equal(self, label: str, actual: object, expected: object) -> None:
        self.check(label, actual == expected, f"got {actual!r}, expected {expected!r}")

    def section(self, title: str) -> None:
        print(f"\n\033[1m{title}\033[0m")

    def finish(self) -> int:
        total = self.passed + len(self.failed)
        print("\n" + "=" * 62)
        if self.failed:
            print(f"\033[31m{len(self.failed)} of {total} checks FAILED\033[0m")
            for label, detail in self.failed:
                print(f"  · {label}" + (f" — {detail}" if detail else ""))
            return 1
        print(f"\033[32mAll {total} checks passed.\033[0m")
        return 0


R = Report()

# ---------------------------------------------------------------------------
# Imports under test
# ---------------------------------------------------------------------------
from portal.data import (  # noqa: E402
    CATEGORIES,
    CHECKLIST_ITEMS,
    DEPARTMENTS,
    ENQUIRY_TEMPLATES,
    ORIENTATION_SCHEDULE,
    PHASES,
    department_by_slug,
    item_by_id,
    total_weight,
)
from portal.logic import mailto, progress  # noqa: E402
from portal.settings import CONTACT, ORIENTATION, PRIMARY_EMAIL  # noqa: E402

DEMO_PRECOMPLETION = ["reg_docs", "email_portal", "tuition", "id_card"]


# ===========================================================================
# 1. Checklist data integrity
# ===========================================================================
R.section("1. Checklist data integrity")

R.equal("exactly 10 checklist items", len(CHECKLIST_ITEMS), 10)
R.equal("weights sum to exactly 100", total_weight(), 100)
R.equal("all item ids are unique", len({i.id for i in CHECKLIST_ITEMS}), len(CHECKLIST_ITEMS))
R.check(
    "every item id matches ^[a-z0-9_]+$",
    all(re.fullmatch(r"[a-z0-9_]+", i.id) for i in CHECKLIST_ITEMS),
    str([i.id for i in CHECKLIST_ITEMS if not re.fullmatch(r"[a-z0-9_]+", i.id)]),
)
R.check(
    "every item has steps and a summary",
    all(i.steps and i.summary for i in CHECKLIST_ITEMS),
)
R.check(
    "every item's phase is one of the three declared phases",
    all(i.phase in PHASES for i in CHECKLIST_ITEMS),
    str([i.phase for i in CHECKLIST_ITEMS if i.phase not in PHASES]),
)
R.check(
    "every item's category is declared in CATEGORIES",
    all(i.category in CATEGORIES for i in CHECKLIST_ITEMS),
    str([i.category for i in CHECKLIST_ITEMS if i.category not in CATEGORIES]),
)
R.check(
    "weights are positive integers",
    all(isinstance(i.weight, int) and i.weight > 0 for i in CHECKLIST_ITEMS),
)
R.check(
    "each phase has at least one item",
    all(any(i.phase == p for i in CHECKLIST_ITEMS) for p in PHASES),
)

# The ten steps the brief asked for must all be represented.
REQUIRED_TOPICS = {
    "reg_docs": "registration",
    "id_card": "student ID card",
    "tuition": "tuition / fee payment",
    "hostel": "hostel / dorm allocation",
    "course_reg": "course registration",
    "library": "library card",
    "email_portal": "email / portal activation",
    "health": "health check",
    "orientation": "orientation attendance",
    "handbook": "handbook acknowledgement",
}
R.equal("all 10 required onboarding topics present", set(REQUIRED_TOPICS), {i.id for i in CHECKLIST_ITEMS})


# ===========================================================================
# 2. Department directory integrity
# ===========================================================================
R.section("2. Department directory integrity")

R.equal("exactly 9 departments", len(DEPARTMENTS), 9)
R.equal("department slugs are unique", len({d.slug for d in DEPARTMENTS}), len(DEPARTMENTS))
R.check(
    "every department email is a valid-looking address",
    all(re.fullmatch(r"[^@\s]+@[^@\s]+\.[a-z]{2,}", d.email) for d in DEPARTMENTS),
    str([d.email for d in DEPARTMENTS if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[a-z]{2,}", d.email)]),
)
R.check(
    "every department has a contact person and role",
    all(d.contact_person and d.contact_role for d in DEPARTMENTS),
)
R.check(
    "every department lists at least 3 services",
    all(len(d.services) >= 3 for d in DEPARTMENTS),
)

REQUIRED_DEPTS = {
    "admissions", "finance", "student_affairs", "advising",
    "library", "it", "health", "hostel", "careers",
}
R.equal("all 9 required offices present", REQUIRED_DEPTS, {d.slug for d in DEPARTMENTS})

R.check(
    "every checklist item's owning department slug resolves",
    all(department_by_slug(i.dept) is not None for i in CHECKLIST_ITEMS),
    str([i.dept for i in CHECKLIST_ITEMS if department_by_slug(i.dept) is None]),
)

R.equal("primary campus email is the official address",
        PRIMARY_EMAIL, "garowecampus@greenhopeuniversity.edu.so")
R.check("primary email appears in the contact block",
        PRIMARY_EMAIL in str(CONTACT.values()))


# ===========================================================================
# 3. Progress maths
# ===========================================================================
R.section("3. Progress maths")

empty = progress.summarize(set())
R.equal("empty checklist reports 0%", empty.percent, 0.0)
R.equal("empty checklist reports 0 done", empty.completed_count, 0)
R.equal("empty checklist reports all 10 pending", len(empty.pending_items), 10)
R.equal("empty checklist status is 'Not started'", empty.status, "Not started")
R.check("empty checklist has no overdue items", empty.overdue_items == ())

full = progress.summarize({i.id for i in CHECKLIST_ITEMS})
R.equal("full checklist reports 100%", full.percent, 100.0)
R.equal("full checklist status is 'Complete'", full.status, "Complete")
R.check("full checklist has nothing pending", len(full.pending_items) == 0)
R.check("full checklist is_complete is True", full.is_complete)

demo = progress.summarize(set(DEMO_PRECOMPLETION))
# reg_docs 12 + email_portal 8 + tuition 15 + id_card 8 = 43
R.equal("demo student is exactly 43% complete", demo.percent, 43.0)
R.equal("demo student completed weight is 43", demo.completed_weight, 43)
R.equal("demo student has 6 steps remaining", len(demo.pending_items), 6)
R.equal("demo student remaining weight is 57", demo.remaining_weight, 57)
R.equal("demo student next_up suggests 3 items", len(demo.next_up), 3)

# Adding a step must move the percentage by exactly its weight.
for item in CHECKLIST_ITEMS:
    got = progress.summarize({item.id}).percent
    if abs(got - float(item.weight)) > 0.05:
        R.check(f"single item {item.id} scores its own weight", False, f"{got} != {item.weight}")
        break
else:
    R.check("each single item scores exactly its own weight", True)

R.check(
    "percent is monotonic as items are added",
    all(
        progress.summarize({i.id for i in CHECKLIST_ITEMS[:n]}).percent
        <= progress.summarize({i.id for i in CHECKLIST_ITEMS[: n + 1]}).percent
        for n in range(len(CHECKLIST_ITEMS) - 1)
    ),
)

R.check("phase stats cover all three phases", len(demo.phases) == 3)
R.equal("phase percentages are each within 0-100",
        all(0 <= s.percent <= 100 for s in demo.phases), True)
R.check("category stats are non-empty", len(demo.categories) > 0)
R.check(
    "category stats are sorted by weight descending",
    all(
        demo.categories[n].total_weight >= demo.categories[n + 1].total_weight
        for n in range(len(demo.categories) - 1)
    ),
)

R.equal("unknown ids are ignored", progress.summarize({"nope", "also-nope"}).percent, 0.0)
R.equal("duplicate ids do not double-count", progress.summarize({"tuition", "tuition"}).percent, 15.0)

R.equal("status_label(0, 10, 0)", progress.status_label(0, 10, 0), "Not started")
R.equal("status_label(100, 10, 10)", progress.status_label(100, 10, 10), "Complete")
R.equal("status_label(50, 10, 5)", progress.status_label(50, 10, 5), "Well underway")
R.equal("status_label(90, 10, 9)", progress.status_label(90, 10, 9), "Almost there")


# ===========================================================================
# 4. Deadlines
# ===========================================================================
R.section("4. Deadlines")

R.equal("parse_iso handles a valid date", progress.parse_iso("2026-09-30"), date(2026, 9, 30))
R.equal("parse_iso returns None for empty", progress.parse_iso(""), None)
R.equal("parse_iso returns None for junk", progress.parse_iso("not-a-date"), None)
R.equal("parse_iso tolerates a datetime string", progress.parse_iso("2026-09-30T12:00:00Z"), date(2026, 9, 30))

_undated = [i for i in CHECKLIST_ITEMS if i.deadline is None]
for item in _undated:
    info = progress.deadline_info(item, date(2026, 9, 19))
    if info.state != "none" or info.days_left is not None:
        R.check(f"undated item {item.id} reports state 'none'", False, str(info))
        break
else:
    R.check("undated items report state 'none'", True)

_fees = item_by_id("tuition")
_fees_due = progress.parse_iso(_fees.deadline)
R.check("tuition deadline parsed", _fees_due is not None, str(_fees.deadline))

R.equal("tuition overdue the day after its deadline",
        progress.deadline_info(_fees, date(2026, 10, 6)).state, "overdue")
R.equal("tuition due-soon within 7 days",
        progress.deadline_info(_fees, date(2026, 10, 1)).state, "due-soon")
R.equal("tuition upcoming well before the deadline",
        progress.deadline_info(_fees, date(2026, 9, 1)).state, "upcoming")
R.equal("tuition due on the day itself is due-soon (0 days)",
        progress.deadline_info(_fees, _fees_due).state, "due-soon")
R.equal("tuition days_left on deadline day is 0",
        progress.deadline_info(_fees, _fees_due).days_left, 0)

R.equal("days_left counts correctly (5 days out)",
        progress.deadline_info(_fees, date(2026, 9, 30)).days_left, 5)

# An overdue set must be reported.
after_all = date(2027, 1, 1)
late = progress.summarize(set(), after_all)
R.check("everything with a deadline is overdue after they all pass",
        all(i.deadline is None for i in late.pending_items) is False
        and all(
            progress.deadline_info(i, after_all).overdue
            for i in late.pending_items if i.deadline
        ))

# next_up priority: soonest deadline first.
#
# Note the ordering, which is easy to get wrong by assumption: orientation
# week ends 25 Sep, so `orientation` has an EARLIER deadline than
# `reg_docs` (30 Sep) and correctly sorts ahead of it. This assertion was
# originally written expecting reg_docs and failed — the code was right and
# the expectation was wrong, so we now assert the real contract.
nxt = progress.next_up(set(), limit=3, today=date(2026, 9, 19))
R.equal("next_up leads with the orientation-week item (deadline 25 Sep)",
        [i.id for i in nxt][0], "orientation")

# The ordering contract itself: every item in the result is as urgent as or
# less urgent than the one before it, comparing (has-deadline, due date).
def _urgency(item):
    due = progress.parse_iso(item.deadline)
    return (0 if due else 1, due.toordinal() if due else 0)

R.check("next_up is sorted by urgency, soonest deadline first",
        all(_urgency(nxt[k]) <= _urgency(nxt[k + 1]) for k in range(len(nxt) - 1)),
        str([(i.id, i.deadline) for i in nxt]))

R.check("next_up never returns a completed item",
        all(i.id not in DEMO_PRECOMPLETION for i in demo.next_up),
        str([i.id for i in demo.next_up]))

# With no dated items left to compete, phase order breaks the tie.
undated = {i.id for i in CHECKLIST_ITEMS if i.deadline is None}
R.check("next_up still returns items once all dated ones are done",
        len(progress.next_up({i.id for i in CHECKLIST_ITEMS} - undated, limit=3)) == 3)

R.equal("next_up respects the limit", len(progress.next_up(set(), limit=2)), 2)
R.equal("next_up of a complete checklist is empty",
        len(progress.next_up({i.id for i in CHECKLIST_ITEMS})), 0)


# ===========================================================================
# 5. mailto construction
# ===========================================================================
R.section("5. mailto construction")

basic = mailto.build_mailto("a@b.so", "Hello", "Body text")
R.check("mailto starts with the scheme and address", basic.startswith("mailto:a@b.so?"))
R.check("mailto carries the subject", "subject=Hello" in basic)
R.check("mailto carries the body", "body=Body" in basic)

R.equal("mailto with no subject/body is just the address",
        mailto.build_mailto("a@b.so"), "mailto:a@b.so")
R.equal("mailto falls back to the primary address when given an empty one",
        mailto.build_mailto("")[:len("mailto:" + PRIMARY_EMAIL)],
        "mailto:" + PRIMARY_EMAIL)

# A newline must survive as an encoded newline, not a literal break.
multi = mailto.build_mailto("a@b.so", "S", "Line one\nLine two")
R.check("newlines are encoded", "%0A" in multi.upper(), multi)
R.check("no raw newline survives", "\n" not in multi, repr(multi))

# The critical regression: an ampersand must not terminate the query early.
amp = mailto.build_mailto("a@b.so", "Fees & Payments", "Please confirm R&D fees & receipts")
parsed = parse_qs(urlparse(amp).query)
R.equal("ampersand in subject survives round-trip",
        parsed.get("subject", [""])[0].replace("%26", "&").replace("&amp;", "&"),
        "Fees & Payments".replace("&", "%26").replace("%26", "&").replace("&amp;", "&"))
R.check("ampersand in body survives round-trip",
        "R&D" in unquote(parsed.get("body", [""])[0]).replace("&amp;", "&")
        or "R%26D" in parsed.get("body", [""])[0],
        str(parsed.get("body")))
R.equal("exactly two query parameters (subject, body)", sorted(parsed.keys()), ["body", "subject"])

# Spaces must be percent-encoded, not '+', for maximum client compatibility.
R.check("spaces are encoded as %20 (quote_via=quote), not '+'",
        "+" not in urlparse(basic).query, urlparse(basic).query)

# Template rendering
ctx = mailto.template_context({"name": "Amina Yusuf", "student_id": "GHU-2026-10482"})
R.equal("template context fills the name", ctx["name"], "Amina Yusuf")
R.equal("template context supplies the campus email", ctx["campus_email"], PRIMARY_EMAIL)
R.equal("template context falls back for a missing key",
        mailto.template_context({})["name"], mailto.DEFAULT_STUDENT["name"])
R.equal("unknown placeholders are left literal, not fatal",
        mailto.render_template("Hi {unknown_person}", {}), "Hi {unknown_person}")
R.check("known placeholders are substituted",
        "GHU-2026-10482" in mailto.render_template("{student_id}", {"student_id": "GHU-2026-10482"}))

R.check("render_template handles an empty string", mailto.render_template("", {}) == "")

# Every shipped template must produce a valid, non-truncated mailto URL.
for template in ENQUIRY_TEMPLATES:
    url = mailto.template_mailto(template, {"name": "Test Student", "student_id": "GHU-1"})
    q = parse_qs(urlparse(url).query)
    if not (url.startswith("mailto:") and "subject" in q and "body" in q):
        R.check(f"template '{template.id}' builds a valid mailto", False, url[:90])
        break
    if "\n" in url:
        R.check(f"template '{template.id}' has no raw newline", False, template.id)
        break
else:
    R.check(f"all {len(ENQUIRY_TEMPLATES)} enquiry templates build valid mailto URLs", True)

R.check("every template's department slug resolves",
        all(department_by_slug(t.dept) is not None for t in ENQUIRY_TEMPLATES),
        str([t.dept for t in ENQUIRY_TEMPLATES if department_by_slug(t.dept) is None]))

# mailto_attrs quoting
R.check("mailto_attrs escapes quotes",
        '"' not in mailto.mailto_attrs('mailto:a@b.so?x="y"').split("href=")[1].split(" ")[0].strip('"').replace("mailto:a@b.so?x=", "").replace("%22", ""),
        mailto.mailto_attrs('mailto:a@b.so?x="y"'))


# ===========================================================================
# 6. Schedule
# ===========================================================================
R.section("6. Orientation schedule")

R.check("schedule has events", len(ORIENTATION_SCHEDULE) >= 8)
R.check(
    "every event has a parseable ISO date",
    all(progress.parse_iso(e.date) is not None for e in ORIENTATION_SCHEDULE),
)
R.check(
    "all events fall inside the configured orientation window",
    all(
        progress.parse_iso(ORIENTATION["week_start"])
        <= progress.parse_iso(e.date)
        <= progress.parse_iso(ORIENTATION["week_end"])
        for e in ORIENTATION_SCHEDULE
    ),
    str([e.date for e in ORIENTATION_SCHEDULE if not (
        progress.parse_iso(ORIENTATION["week_start"])
        <= progress.parse_iso(e.date)
        <= progress.parse_iso(ORIENTATION["week_end"]))]),
)
R.check("schedule dates are chronological",
        [e.date for e in ORIENTATION_SCHEDULE] == sorted(e.date for e in ORIENTATION_SCHEDULE))
R.check("every event has a non-empty venue and title",
        all(e.venue and e.title for e in ORIENTATION_SCHEDULE))
R.check("every event tag is Mandatory / Recommended / Social",
        all(e.tag in {"Mandatory", "Recommended", "Social"} for e in ORIENTATION_SCHEDULE),
        str({e.tag for e in ORIENTATION_SCHEDULE}))


# ===========================================================================
# 7. Configuration
# ===========================================================================
R.section("7. Configuration")

R.check("config.yaml loaded (not just defaults)",
        (PROJECT_ROOT / "config.yaml").is_file())
R.check("orientation window start is a Monday",
        progress.parse_iso(ORIENTATION["week_start"]).weekday() == 0,
        str(progress.parse_iso(ORIENTATION["week_start"])))
R.check("registration deadline is after orientation week",
        progress.parse_iso(ORIENTATION["registration_deadline"])
        > progress.parse_iso(ORIENTATION["week_end"]))
R.check("course-registration deadline is the latest of the three",
        progress.parse_iso(ORIENTATION["course_registration_deadline"])
        > progress.parse_iso(ORIENTATION["fees_deadline"]))
R.check("contact block has an office and hours",
        bool(CONTACT.get("office")) and bool(CONTACT.get("hours")))


# ===========================================================================
# 8. Source-level sanity checks
# ===========================================================================
R.section("8. Source-level checks")

import ast  # noqa: E402

VIEW_DIR = PROJECT_ROOT / "portal" / "views"
SOURCE_FILES = sorted(
    list(VIEW_DIR.glob("*.py"))
    + [PROJECT_ROOT / "app.py"]
    + sorted((PROJECT_ROOT / "portal").glob("*.py"))
    + sorted((PROJECT_ROOT / "portal" / "logic").glob("*.py"))
)

R.check("source files found", len(SOURCE_FILES) >= 12, f"{len(SOURCE_FILES)} files")

for path in SOURCE_FILES:
    try:
        ast.parse(path.read_text(encoding="utf-8"))
    except SyntaxError as exc:
        R.check(f"{path.name} parses as valid Python", False, str(exc))
        break
else:
    R.check(f"all {len(SOURCE_FILES)} source files parse as valid Python", True)

# Every view module must exist and define render().
for name in ("hero", "checklist", "progress", "directory"):
    path = VIEW_DIR / f"{name}.py"
    if not path.is_file():
        R.check(f"views/{name}.py exists", False, "missing")
        continue
    tree = ast.parse(path.read_text(encoding="utf-8"))
    funcs = {n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)}
    R.check(f"views/{name}.py defines render()", "render" in funcs)

# The Streamlit APIs actually used must exist in the installed version —
# catches typos like st.toggle / st.container(border=) on an old release.
try:
    import streamlit as st  # noqa: E402

    for api in ("tabs", "columns", "checkbox", "toggle", "expander", "button",
                "text_input", "selectbox", "dataframe", "plotly_chart",
                "toast", "rerun", "container", "markdown", "set_page_config"):
        R.check(f"streamlit.{api} exists", hasattr(st, api))

    R.check("st.column_config.NumberColumn exists (used by the progress table)",
            hasattr(st.column_config, "NumberColumn"))
except ImportError:
    print("  \033[33mSKIP\033[0m  streamlit not installed — runtime API checks skipped")

# CSS sanity: every $placeholder in styles.py must be supplied by the theme,
# otherwise string.Template.substitute raises at render time.
STYLES = (PROJECT_ROOT / "portal" / "styles.py").read_text(encoding="utf-8")
declared = set(re.findall(r"\$\{?([a-zA-Z_][a-zA-Z0-9_]*)\}?", STYLES))
from portal.settings import THEME as _THEME  # noqa: E402

supplied = set(_THEME) | {"font_display", "font_body", "hero_url"}
missing = declared - supplied
R.check("every CSS placeholder has a theme value", not missing, str(sorted(missing)))

# The two icon characters used in the directory must survive encoding.
R.check("emoji in view source is intact",
        "📍" in (VIEW_DIR / "directory.py").read_text(encoding="utf-8"))


# ===========================================================================
sys.exit(R.finish())
