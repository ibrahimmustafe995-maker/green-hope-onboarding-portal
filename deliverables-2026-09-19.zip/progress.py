"""Progress mathematics for the freshman onboarding checklist.

Everything here is a pure function of ``(completed_ids, today)`` — no
Streamlit state, no I/O — which makes the whole progress model trivially
unit-testable and easy to reason about.

The percentage is a **weighted** sum, not a plain tick count: paying fees or
registering for courses genuinely gates a student's start, so those carry
more weight than, say, activating a library card. The ten weights sum to
exactly 100 (asserted in the test suite), so the percentage is simply the
sum of the weights of completed items.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from typing import Iterable, List, Sequence, Tuple

from portal.data import CATEGORIES, CHECKLIST_ITEMS, PHASES, ChecklistItem

__all__ = [
    "GroupStat",
    "ProgressSummary",
    "DeadlineInfo",
    "as_date",
    "deadline_info",
    "summarize",
    "phase_stats",
    "category_stats",
    "next_up",
    "status_label",
    "parse_iso",
]


# ===========================================================================
# Dates
# ===========================================================================
def parse_iso(value: str | None) -> date | None:
    """Parse an ISO ``YYYY-MM-DD`` string, returning ``None`` when invalid."""
    if not value:
        return None
    try:
        return datetime.strptime(str(value)[:10], "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None


def as_date(value: date | str | None) -> date:
    """Coerce a date or ISO string to a ``date``, defaulting to today."""
    if isinstance(value, date):
        return value
    return parse_iso(value) or date.today()


# ===========================================================================
# Result objects
# ===========================================================================
@dataclass(frozen=True)
class GroupStat:
    """Completion figures for one phase or one category."""

    name: str
    completed_count: int
    total_count: int
    completed_weight: int
    total_weight: int

    @property
    def percent(self) -> float:
        """Weighted completion for this group, 0–100."""
        if self.total_weight <= 0:
            return 0.0
        return round(100.0 * self.completed_weight / self.total_weight, 1)

    @property
    def is_complete(self) -> bool:
        return self.total_count > 0 and self.completed_count == self.total_count


@dataclass(frozen=True)
class DeadlineInfo:
    """Where an item stands relative to its deadline."""

    item: ChecklistItem
    days_left: int | None      # None when the item has no dated deadline
    overdue: bool
    state: str                 # "none" | "overdue" | "due-soon" | "upcoming"


@dataclass(frozen=True)
class ProgressSummary:
    """The complete picture behind the progress dashboard."""

    percent: float
    completed_weight: int
    total_weight: int
    completed_count: int
    total_count: int
    phases: Tuple[GroupStat, ...]
    categories: Tuple[GroupStat, ...]
    completed_items: Tuple[ChecklistItem, ...]
    pending_items: Tuple[ChecklistItem, ...]
    next_up: Tuple[ChecklistItem, ...]
    overdue_items: Tuple[ChecklistItem, ...]

    @property
    def status(self) -> str:
        """A short human label for the current state."""
        return status_label(self.percent, self.total_count, self.completed_count)

    @property
    def remaining_weight(self) -> int:
        return max(0, self.total_weight - self.completed_weight)

    @property
    def is_complete(self) -> bool:
        return self.total_count > 0 and self.completed_count == self.total_count


# ===========================================================================
# Core calculations
# ===========================================================================
def _normalise(completed: Iterable[str]) -> set[str]:
    """Accept any iterable of ids and return a clean set of strings."""
    return {str(x) for x in (completed or []) if x}


def _pct(completed_weight: int, total_weight: int) -> float:
    if total_weight <= 0:
        return 0.0
    return round(100.0 * completed_weight / total_weight, 1)


def status_label(percent: float, total: int, done: int) -> str:
    """Bucket a percentage into a short, motivating status label."""
    if total > 0 and done >= total:
        return "Complete"
    if done == 0:
        return "Not started"
    if percent >= 85:
        return "Almost there"
    if percent >= 50:
        return "Well underway"
    return "Getting started"


def phase_stats(completed: Iterable[str]) -> Tuple[GroupStat, ...]:
    """Weighted completion for each of the three orientation phases."""
    done = _normalise(completed)
    stats: List[GroupStat] = []
    for phase in PHASES:
        items = [i for i in CHECKLIST_ITEMS if i.phase == phase]
        if not items:
            continue
        stats.append(
            GroupStat(
                name=phase,
                completed_count=sum(1 for i in items if i.id in done),
                total_count=len(items),
                completed_weight=sum(i.weight for i in items if i.id in done),
                total_weight=sum(i.weight for i in items),
            )
        )
    return tuple(stats)


def category_stats(completed: Iterable[str]) -> Tuple[GroupStat, ...]:
    """Weighted completion per category, busiest categories first."""
    done = _normalise(completed)
    stats: List[GroupStat] = []
    for category in CATEGORIES:
        items = [i for i in CHECKLIST_ITEMS if i.category == category]
        if not items:
            continue
        stats.append(
            GroupStat(
                name=category,
                completed_count=sum(1 for i in items if i.id in done),
                total_count=len(items),
                completed_weight=sum(i.weight for i in items if i.id in done),
                total_weight=sum(i.weight for i in items),
            )
        )
    return tuple(sorted(stats, key=lambda s: (-s.total_weight, s.name)))


def deadline_info(item: ChecklistItem, today: date | str | None = None) -> DeadlineInfo:
    """Work out how an item's deadline stands relative to ``today``."""
    ref = as_date(today)
    due = parse_iso(item.deadline)
    if due is None:
        return DeadlineInfo(item=item, days_left=None, overdue=False, state="none")

    days = (due - ref).days
    if days < 0:
        state = "overdue"
    elif days <= 7:
        state = "due-soon"
    else:
        state = "upcoming"
    return DeadlineInfo(item=item, days_left=days, overdue=state == "overdue", state=state)


def next_up(
    completed: Iterable[str],
    limit: int = 3,
    today: date | str | None = None,
) -> Tuple[ChecklistItem, ...]:
    """The most useful next steps: soonest deadline first, then heaviest weight.

    Ordering, in priority order:

    1. items that have a deadline, before items that do not;
    2. overdue items, before those still in the future;
    3. the earliest due date;
    4. the earlier orientation phase;
    5. the heavier weight.

    Note that (3) decides ties independently of phase: orientation
    attendance (deadline 25 Sep) correctly outranks registration (30 Sep),
    because the event both ends sooner and cannot be made up afterwards.
    """
    done = _normalise(completed)
    ref = as_date(today)

    def sort_key(item: ChecklistItem) -> tuple:
        due = parse_iso(item.deadline)
        # Items with a deadline come first, ordered by how soon it falls.
        has_deadline = 0 if due else 1
        overdue_first = 0 if (due and due < ref) else 1
        return (
            has_deadline,
            overdue_first,
            due.toordinal() if due else 0,
            PHASES.index(item.phase) if item.phase in PHASES else 99,
            -item.weight,
        )

    pending = [i for i in CHECKLIST_ITEMS if i.id not in done]
    pending.sort(key=sort_key)
    return tuple(pending[: max(0, limit)])


def summarize(completed: Iterable[str], today: date | str | None = None) -> ProgressSummary:
    """Compute every figure the progress dashboard needs, in one pass."""
    done = _normalise(completed)

    completed_items = tuple(i for i in CHECKLIST_ITEMS if i.id in done)
    pending_items = tuple(i for i in CHECKLIST_ITEMS if i.id not in done)

    total_weight = sum(i.weight for i in CHECKLIST_ITEMS)
    completed_weight = sum(i.weight for i in completed_items)

    overdue = tuple(
        i
        for i in pending_items
        if (info := deadline_info(i, today)) and info.overdue
    )

    return ProgressSummary(
        percent=_pct(completed_weight, total_weight),
        completed_weight=completed_weight,
        total_weight=total_weight,
        completed_count=len(completed_items),
        total_count=len(CHECKLIST_ITEMS),
        phases=phase_stats(done),
        categories=category_stats(done),
        completed_items=completed_items,
        pending_items=pending_items,
        next_up=next_up(done, limit=3, today=today),
        overdue_items=overdue,
    )
